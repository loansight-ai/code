"""Compatibility strategy: previous forward-only hierarchy inference."""
import re
from .markers import marker
from .profiles import GENERIC_PROFILE
from .numbering_state import DepthNumberingState, explicit_path_parent
from ..settings import get_config

def infer_sequential(blocks,profile=GENERIC_PROFILE):
    rules=get_config()["hierarchy"]
    nodes=[{'id':'root','parent_id':None,'level':0,'role':profile.root_role,'title':profile.root_title,'source_block_id':None,
            'confidence':'high','evidence':['수집 단위'],'content_block_ids':[]}]
    byid={'root':nodes[0]}; stack=[]; candidates=[]; reviews=[]; active_top=None
    depth_state=DepthNumberingState()
    previous_top_value=None; content_owner='root'; pending_unresolved={}
    for block in blocks:
        text=block['text_normalized']; m=marker(text,profile) if block['type']!='table' else None
        block['owner_node_id']=content_owner
        if not m:
            byid[block['owner_node_id']]['content_block_ids'].append(block['id']);continue
        cls=block['format_hints']['classes']; evidence=[]; flags=[]
        if profile.is_document_title(cls,text):
            candidates.append({'block_id':block['id'],'marker':m,'decision':'document_title','reason':profile.document_title_evidence})
            byid['root']['content_block_ids'].append(block['id']);block['owner_node_id']='root';continue
        sentence=bool(re.search(profile.sentence_end_pattern,text))
        top_hint=profile.is_top_heading_hint(cls,block['source_tag'])
        bold=block['format_hints']['bold_tag'] or any('bold' in s or re.search(r'font-weight\s*:\s*[7-9]00',s) for s in block['format_hints']['inline_styles'])
        if top_hint:evidence.append(profile.top_heading_evidence)
        if bold:evidence.append('inline bold hint')
        is_top=m['type']=='number_dot' and (top_hint or (len(text)<rules['top_title_max_exclusive'] and not sentence and (previous_top_value is None and m['value']==1 or previous_top_value is not None and m['value']==previous_top_value+1)))
        confidence='medium'; role='numbered_item' if sentence or len(text)>rules['numbered_item_min_exclusive'] else 'heading'
        if is_top:
            parent='root';stack=[];active_top=None;pending_unresolved={};previous_top_value=m['value'];confidence='high' if top_hint else 'medium'
            evidence.append('상위 주석 번호/제목 서식' if top_hint else '상위 번호 연속성과 짧은 제목')
        elif m['type']=='numeric_path':
            sibling=depth_state.path_sibling(m)
            if sibling is not None:
                parent=sibling['parent_id']
                stack=stack[:stack.index(sibling)]
                evidence.append('depth별 동일 경로 형식과 부모 접두사 일치')
                if m['value']==sibling['marker_value']+1:
                    evidence.append('동일 숫자 경로 형제의 번호 연속');confidence='high'
                else:
                    flags.append('동일 숫자 경로의 번호 건너뜀')
            else:
                found=explicit_path_parent(m,stack,active_top)
                if found:
                    parent=found['id'];stack=stack[:stack.index(found)+1]
                    evidence.append('명시적 숫자 경로의 부모 접두사 일치');confidence='high'
                    if m.get('enclosure')=='parenthesized' and found['marker_type']=='number_close':
                        confidence='medium';flags.append('부모·자식의 괄호 표기 차이: 근접 숫자 접두사로 연결')
                else:
                    parent=None;flags.append('숫자 경로의 부모 접두사 미발견')
        else:
            matches=depth_state.matching_family(m,active_top)
            same=next((n for n in matches if n['table_context']==block['table_context']),matches[0] if matches else None)
            pending_key=(active_top,m['family'],tuple(block['table_context']))
            if pending_key in pending_unresolved and m['value']>pending_unresolved[pending_key]:
                parent=None;flags.append('동일 번호 묶음의 선행 항목 부모가 미확정')
            elif same and m['value']>same['marker_value']:
                parent=same['parent_id'];stack=stack[:stack.index(same)]
                if m['value']==same['marker_value']+1:evidence.append('같은 번호 형식의 연속 항목')
                else:flags.append('같은 번호 형식의 번호 건너뜀')
            elif m['value']==1:
                if same:
                    current=stack[-1] if stack else None
                    ctx=block['table_context']; oldctx=same['table_context']
                    if oldctx and len(ctx)>len(oldctx) and ctx[:len(oldctx)]==oldctx:
                        parent=current['id'];evidence.append('배치용 표 내부 중첩과 번호 재시작');flags.append('동일 형식 중첩의 부모는 표 문맥 추정')
                    else:
                        # A same-style restart does not establish whether it is a child or sibling.
                        parent=None;flags.append('같은 형식의 번호 재시작: 부모 판단 보류')
                else:
                    parent=stack[-1]['id'] if stack else None
                    evidence.append('현재 항목 내부에서 새 번호 형식이 1부터 시작')
                    flags.append('새 번호 형식의 부모는 문맥 추정')
            else:
                parent=None;flags.append('선행 동일 형식 항목/시작 번호 미발견')
        if m['type']=='number_dot' and not is_top and len(text)<rules['top_title_max_exclusive'] and not sentence:flags.append('짧은 숫자 제목의 상위/하위 구분 검토')
        if role=='numbered_item':flags.append('제목이 아닌 번호 목록/문장 가능성')
        if parent is None:
            confidence='low'
            pending_unresolved[(active_top,m['family'],tuple(block['table_context']))]=m['value']
        if parent is not None and byid[parent]['level'] is None:
            confidence='low';flags.append('상위 항목의 깊이가 미확정')
        if len(text)>rules['long_numbered_min_exclusive']:confidence='low';flags.append('긴 번호 문장')
        if not active_top and not is_top:flags.append('상위 주석 미확정')
        if parent is not None:
            parentlevel=byid[parent]['level'];level=parentlevel+1 if parentlevel is not None else None
        else:level=None
        node={'id':f'n{len(nodes):05d}','parent_id':parent,'level':level,'role':role,'title':m['title'],
            'marker_raw':m['raw'],'marker_type':m['type'],'marker_family':m['family'],'marker_value':m['value'],
            'numeric_path':m['path'] if m['type']=='numeric_path' else None,
            'source_block_id':block['id'],'source_xpath':block['source_xpath'],'confidence':confidence,
            'table_context':block['table_context'],
            'evidence':evidence,'review_flags':flags,'content_block_ids':[],
            'context_top_node_id':active_top,'status':'unresolved' if parent is None else 'inferred'}
        nodes.append(node);byid[node['id']]=node
        if is_top:active_top=node['id'];node['context_top_node_id']=node['id']
        # Keep established ancestors when an ambiguous item is quarantined, so one restart
        # does not erase the surrounding policy hierarchy. Its content still belongs to it.
        if parent is not None:stack.append(node)
        depth_state.update(stack)
        content_owner=node['id']
        block['owner_node_id']=node['id'];block['heading_node_id']=node['id']
        candidates.append({'block_id':block['id'],'marker':m,'decision':role,'node_id':node['id']})
        if flags:reviews.append({'node_id':node['id'],'block_id':block['id'],'text':text,'flags':flags,'confidence':confidence})
    return nodes,candidates,reviews
