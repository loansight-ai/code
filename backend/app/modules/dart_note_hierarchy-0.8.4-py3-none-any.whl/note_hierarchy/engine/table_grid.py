"""Bounded HTML span expansion shared by label extraction and structural diff."""
from lxml import html
from .common import norm
from ..settings import get_config

ROW_PATH = './tr | ./thead/tr | ./tbody/tr | ./tfoot/tr'


def expand_table(raw_html):
    limits=get_config()["limits"]
    root = html.fromstring(raw_html)
    if root.xpath('.//table | .//img'):
        return {'supported': False, 'reason': '중첩 표 또는 이미지'}
    rows = root.xpath(ROW_PATH)
    if len(rows) > limits['max_rows']:
        return {'supported': False, 'reason': '표 크기 한도'}
    occupied, source_cells = {}, []
    for ri, row in enumerate(rows):
        cells, ci = [], 0
        for cell in row:
            if cell.tag not in ('td', 'th'):
                continue
            while (ri, ci) in occupied:
                ci += 1
            try:
                rs = max(1, int(cell.get('rowspan', '1')))
                cs = max(1, int(cell.get('colspan', '1')))
            except ValueError:
                return {'supported': False, 'reason': '잘못된 병합 속성'}
            if cs > limits['max_columns'] or ci+cs > limits['max_columns'] or rs > limits['max_rowspan'] or len(occupied)+rs*cs > limits['max_expanded_cells']:
                return {'supported': False, 'reason': '표 크기 한도'}
            text = cell.text_content()
            item = {'text': norm(text), 'display_text': ' '.join(text.split()),
                    'row': ri, 'col': ci, 'tag': cell.tag, 'rowspan': rs, 'colspan': cs,
                    'in_thead': row.getparent() is not None and row.getparent().tag == 'thead'}
            for r in range(ri, min(ri+rs, len(rows))):
                for c in range(ci, ci+cs):
                    occupied[r, c] = item
            cells.append(item)
            ci += cs
        source_cells.append(cells)
    width = max((c for _, c in occupied), default=-1)+1
    return {'supported': True, 'source_cells': source_cells, 'width': width,
            'grid': [[occupied.get((r, c)) for c in range(width)] for r in range(len(rows))]}
