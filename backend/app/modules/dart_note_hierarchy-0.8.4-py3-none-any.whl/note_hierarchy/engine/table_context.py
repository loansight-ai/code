"""Shared table-neighbor traversal; domain-specific boundaries stay with callers."""


def neighbor_block_ids(blocks, index, owner_id, stop_after=None):
    before = []
    cursor = index-1
    while cursor >= 0:
        block = blocks[cursor]
        if block['type'] == 'table' or block['owner_node_id'] != owner_id:
            break
        before.append(block['id'])
        if block.get('heading_node_id'):
            break
        cursor -= 1
    before.reverse()
    after = []
    cursor = index+1
    while cursor < len(blocks):
        block = blocks[cursor]
        if block['type'] == 'table' or block.get('heading_node_id') or block['owner_node_id'] != owner_id:
            break
        if stop_after is not None and stop_after(block):
            break
        after.append(block['id'])
        cursor += 1
    return before, after, cursor


def breadcrumb(owner, nodes):
    result, visited = [], set()
    current = owner
    while current and current['id'] != 'root' and current['id'] not in visited:
        visited.add(current['id'])
        result.append({'node_id': current['id'], 'text': current.get('marker_raw', '')+' '+current['title'],
                       'block_id': current['source_block_id']})
        current = nodes.get(current['parent_id'])
    result.reverse()
    return result
