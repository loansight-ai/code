import re
from .profiles import GENERIC_PROFILE

from ..settings import DEFAULT_CONFIG, get_config

HANGUL=DEFAULT_CONFIG['markers']['hangul_alphabet']
PATTERNS=DEFAULT_CONFIG['markers']['patterns']


def marker(text,profile=GENERIC_PROFILE):
    config=get_config()
    alphabet=config['markers']['hangul_alphabet']
    # Avoid legal entity prefixes, dates, percentages, bare decimals, and numeric table values.
    if profile.excluded_marker_prefix_pattern and re.match(profile.excluded_marker_prefix_pattern,text):return None
    for typ,pattern in config['markers']['patterns']:
        pattern=pattern.replace('{hangul}',re.escape(alphabet))
        m=re.fullmatch(pattern,text)
        if not m:continue
        title=m['title'].strip(); raw=m['mark']
        if not re.search(r'[가-힣A-Za-z]',title):continue
        if typ=='numeric_path':
            parts=[int(x) for x in re.findall(r'\d+',raw)]
            if parts[0]==0 or parts[0]>profile.max_marker_value or len(parts)>config['hierarchy']['max_numeric_path_parts']:continue
            sep='-' if '-' in raw else '.'
            enclosure='parenthesized' if raw.startswith('(') else 'plain'
            return {'raw':raw,'type':typ,'value':parts[-1],'path':parts,'separator':sep,'enclosure':enclosure,'title':title,'family':typ+sep+('()' if enclosure=='parenthesized' else '')}
        if typ.startswith('number'):
            value=int(re.search(r'\d+',raw)[0])
            if value==0 or value>profile.max_marker_value:continue
        elif typ=='circled':value=ord(raw)-ord('①')+1 if raw<='⑳' else ord(raw)-ord('㉑')+21
        elif typ.startswith('hangul'):value=alphabet.index(re.search('['+re.escape(alphabet)+']',raw)[0])+1
        elif typ=='roman':
            chars=re.sub('[^ivxl]','',raw.lower()); values={'i':1,'v':5,'x':10,'l':50}
            value=sum(-values[c] if i+1<len(chars) and values[c]<values[chars[i+1]] else values[c] for i,c in enumerate(chars))
        else:value=ord(re.search('[A-Za-z]',raw)[0].lower())-96
        return {'raw':raw,'type':typ,'value':value,'path':[value],'title':title,'family':typ}
    return None

