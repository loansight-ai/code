"""Retain ancestor containment and list order independently of direct parents."""


def preserve_partial_relations(nodes,models):
    """Keep containment and list order without inventing an immediate parent."""
    byid={n['id']:n for n in nodes}
    byblock={n['source_block_id']:n for n in nodes[1:]}
    for node in nodes[1:]:
        ancestors=['root'];top=node.get('context_top_node_id')
        if top and top!=node['id']:ancestors.append(top)
        lineage=[];parent=node['parent_id']
        while parent and parent!='root':
            lineage.append(parent);parent=byid[parent]['parent_id']
        ancestors.extend(p for p in reversed(lineage) if p not in ancestors)
        node['known_ancestor_ids']=ancestors
        node['containment_status']=('ancestor_known_parent_unknown' if node['parent_id'] is None and top
                                    else 'parent_known' if node['parent_id'] else 'document_only')
        node['ancestor_evidence']=['상위 주석 시작부터 다음 상위 주석 직전까지의 범위'] if top and top!=node['id'] else []
        node['sibling_group_id']=None
        node['previous_sibling_id']=None;node['next_sibling_id']=None
    for model in models:
        members=[byblock[bid] for bid in model['member_block_ids']]
        model['sibling_node_ids']=[n['id'] for n in members]
        model['sibling_relation_status']='inferred' if len(members)>1 else 'single_item'
        model['known_ancestor_ids']=members[0]['known_ancestor_ids'][:]
        for index,node in enumerate(members):
            node['sibling_group_id']=model['id'];node['sibling_index']=index
            node['previous_sibling_id']=members[index-1]['id'] if index else None
            node['next_sibling_id']=members[index+1]['id'] if index+1<len(members) else None
