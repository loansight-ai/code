"""HTML structure engine. No workspace paths, credentials, or network access."""
