"""Recognize bounded same-level split ordinals without treating every path as one."""
from collections import defaultdict
from ..settings import get_config


def integer_style(m):
    if m['type'] in ('number_dot','number_close','number_paren'):return m['type']
    if m['type']!='numeric_path' or m.get('separator')!='-' or len(m['path'])!=2:return None
    if m['raw'].startswith('('):return 'number_paren'
    return 'number_close' if m['raw'].endswith(')') else 'number_dot'


def annotate_split_numbers(candidates,blocks,profile):
    rules=get_config()['hierarchy']
    if not rules['support_split_sibling_numbers']:return
    skeletons=defaultdict(list)
    for index,c in enumerate(candidates):
        if c['decision'] in ('document_title','repeated_content'):continue
        style=integer_style(c['marker'])
        if style:skeletons[style].append(index)
    groups=0
    for style,indices in skeletons.items():
        cursor=0
        while cursor<len(indices):
            if candidates[indices[cursor]]['marker']['type']!='numeric_path':cursor+=1;continue
            stop=cursor
            while stop<len(indices) and candidates[indices[stop]]['marker']['type']=='numeric_path':stop+=1
            run=indices[cursor:stop]
            left=indices[cursor-1] if cursor else None;right=indices[stop] if stop<len(indices) else None
            cursor=stop
            if left is None or right is None:continue
            if style!='number_dot' and any(c['is_top'] for c in candidates[left+1:right]):continue
            lm=candidates[left]['marker'];rm=candidates[right]['marker']
            # Exact outer notation and layout context must agree; no enclosure
            # conversion or distant parent guess is used to establish a split.
            context=blocks[candidates[left]['position']]['table_context']
            if any(blocks[candidates[i]['position']]['table_context']!=context for i in run+[right]):continue
            bymajor=[]
            for index in run:
                major,minor=candidates[index]['marker']['path']
                if not bymajor or bymajor[-1][0]!=major:bymajor.append((major,[]))
                bymajor[-1][1].append(minor)
            majors=[major for major,_ in bymajor]
            if majors!=list(range(lm['value']+1,rm['value'])):continue
            minimum=rules['split_sibling_min_members']
            if any(len(parts)<minimum or parts!=list(range(1,len(parts)+1)) for _,parts in bymajor):continue
            groups+=1
            for index in run:
                c=candidates[index];m=c['marker'];major,minor=m['path']
                c['numbering_interpretation']='split_sibling'
                c['split_group_id']=f'split{groups:05d}'
                c['split_evidence']={'before_block_id':candidates[left]['block_id'],
                    'after_block_id':candidates[right]['block_id'],'major_sequence':[lm['value'],*majors,rm['value']],
                    'evidence':'앞뒤 같은 형식의 번호 사이에서 다음 주번호와 연속 분할 번호가 일치'}
                c['inference_marker']={**m,'type':style,'family':style,'value':major,'path':[major],
                    'split_index':minor}
    if not groups:return
    # Split headers change the coarse boundaries, so later N. headings must be
    # reconsidered too, including consecutive split majors such as 14-x, 15-x.
    previous=None
    for c in candidates:
        if c['decision'] in ('document_title','repeated_content'):continue
        m=c.get('inference_marker',c['marker']);text=blocks[c['position']]['text_normalized']
        short=len(text)<rules['top_title_max_exclusive'] and not c['sentence']
        ordered=(previous is None and m['value']==1 or previous is not None and
                 (m['value']==previous+1 or m.get('split_index',0)>1 and m['value']==previous))
        c['is_top']=m['type']=='number_dot' and (c['top_hint'] or short and ordered)
        if c['is_top']:previous=m['value']
