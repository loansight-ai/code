from collections import Counter
import re

def chars(text):return len(re.sub(r'\s+','',text))


def table_shape(el):
    rows=el.xpath('./tr | ./thead/tr | ./tbody/tr | ./tfoot/tr')
    cells=[c for row in rows for c in row if c.tag in ('td','th')]
    return {'table_count':1,'html_table_elements':1+len(el.xpath('.//table')),'table_rows':len(rows),'table_cells':len(cells),
            'merged_cells':sum(c.get('rowspan','1')!='1' or c.get('colspan','1')!='1' for c in cells)}


def measure(blocks,shape):
    result=Counter({'block_count':len(blocks),'narrative_characters':0,'heading_characters':0,'table_text_characters':0,
                    'table_count':0,'html_table_elements':0,'table_rows':0,'table_cells':0,'merged_cells':0})
    for b in blocks:
        if b['type']=='table':result['table_text_characters']+=chars(b['text']);result.update(shape[b['id']])
        elif b.get('heading_node_id'):result['heading_characters']+=chars(b['text'])
        else:result['narrative_characters']+=chars(b['text'])
    result['text_characters_total']=result['narrative_characters']+result['heading_characters']+result['table_text_characters']
    return dict(result)


def attach_content_metrics(data,shape):
    blocks=data['blocks'];nodes=data['nodes'];bmap={b['id']:b for b in blocks}
    descendants={n['id']:set(n['content_block_ids']) | ({n['source_block_id']} if n.get('source_block_id') else set()) for n in nodes}
    direct={nid:set(bids) for nid,bids in descendants.items()}
    for n in reversed(nodes):
        if n['parent_id'] is not None:descendants[n['parent_id']].update(descendants[n['id']])
    # Document root always covers the whole source, including quarantined unresolved nodes.
    descendants['root']=set(bmap)
    tableid={b['id']:'tbl_'+b['id'] for b in blocks if b['type']=='table'}
    for n in nodes:
        n['content_metrics']={'direct':measure([bmap[bid] for bid in direct[n['id']]],shape),
                              'subtree':measure([bmap[bid] for bid in descendants[n['id']]],shape)}
        n['direct_table_unit_ids']=[tableid[b['id']] for b in blocks if b['id'] in direct[n['id']] and b['type']=='table']
        n['subtree_table_unit_ids']=[tableid[b['id']] for b in blocks if b['id'] in descendants[n['id']] and b['type']=='table']
        n['content_metrics']['scope_note']='직속은 해당 노드의 제목·본문, subtree는 확정 부모 연결의 하위 항목 포함. root는 미확정 노드도 포함한 문서 전체.'
