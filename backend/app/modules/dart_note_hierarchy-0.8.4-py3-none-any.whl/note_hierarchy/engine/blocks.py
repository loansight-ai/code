from .common import norm,clean,sha
from .profiles import GENERIC_PROFILE

def extract_blocks(root,profile=GENERIC_PROFILE):
    body=root.find('body') if root.tag=='html' else root
    if body is None:body=root
    tree=root.getroottree(); blocks=[]; tables=[]; elements={}
    def add(text,el,kind,context,segment=None):
        if not norm(text):return
        block={'id':f'b{len(blocks)+1:06d}','order':len(blocks),'type':kind,'text':text,
               'text_normalized':clean(text),'source_xpath':tree.getpath(el),'source_tag':el.tag,
               'source_attributes':dict(el.attrib),'table_context':list(context),'segment':segment}
        # These are source hints, not browser-computed CSS or guaranteed semantic headings.
        inline=list(el.iter()) if kind!='table' else [el]
        block['format_hints']={'classes':el.get('class',''),
            'inline_styles':list(dict.fromkeys(x.get('style') for x in inline if isinstance(x.tag,str) and x.get('style'))),
            'bold_tag':any(x.tag in ('b','strong') for x in inline),
            'anchors':[x.get('name') or x.get('id') for x in inline if x.tag=='a' and (x.get('name') or x.get('id'))]}
        blocks.append(block);elements[block['id']]=el
    def lines(el):
        buf=['']
        def rec(node):
            if node.text:buf[-1]+=node.text
            for child in node:
                if child.tag=='br':buf.append('')
                elif isinstance(child.tag,str) and not (profile.ignore_noncontent_text and child.tag in ('script','style')):rec(child)
                if child.tail:buf[-1]+=child.tail
        rec(el)
        return buf
    def walk(el,context):
        if not isinstance(el.tag,str) or el.tag in ('script','style','head'):return
        if el.tag=='table':
            layout=any(c in el.get('class','').split() for c in profile.layout_table_classes)
            tid=f't{len(tables)+1:05d}'
            rows=el.xpath('./tr | ./thead/tr | ./tbody/tr | ./tfoot/tr')
            cells=el.xpath('./tr/td | ./tr/th | ./thead/tr/td | ./thead/tr/th | ./tbody/tr/td | ./tbody/tr/th | ./tfoot/tr/td | ./tfoot/tr/th')
            tab={'id':tid,'source_xpath':tree.getpath(el),'source_attributes':dict(el.attrib),'role_inferred':'layout' if layout else 'data',
                'role_evidence':profile.layout_table_evidence if layout else profile.data_table_evidence,
                'first_block_order':len(blocks),'rows':len(rows),'cells':len(cells)}
            tables.append(tab)
            if not layout:
                add(''.join(el.itertext()),el,'table',context+[tid])
                tab['last_block_order']=len(blocks)-1
                return
            context=context+[tid]
        if el.tag in ('p','h1','h2','h3','h4','h5','h6','td','th') and not el.xpath('.//table | .//p | .//h1 | .//h2 | .//h3'):
            parts=lines(el);nonempty=sum(bool(norm(t)) for t in parts)
            for index,text in enumerate(parts):
                before=len(blocks);add(text,el,'paragraph',context,index)
                if len(blocks)>before:blocks[-1]['source_element_nonempty_segments']=nonempty
        else:
            if el.text:add(el.text,el,'text',context)
            for child in el:
                walk(child,context)
                if child.tail:add(child.tail,el,'text',context)
        if el.tag=='table':tab['last_block_order']=len(blocks)-1
    walk(body,[])
    def visible_source_text(el):
        if not isinstance(el.tag,str) or el.tag in ('script','style','head'):return ''
        return (el.text or '')+''.join(visible_source_text(c)+(c.tail or '') for c in el)
    original=norm(visible_source_text(body) if profile.ignore_noncontent_text else ''.join(body.itertext()))
    reconstructed=norm(''.join(b['text'] for b in blocks))
    coverage={'normalized_text_equal':original==reconstructed,'source_characters':len(original),'block_characters':len(reconstructed),
              'source_normalized_sha256':sha(original.encode()),'block_normalized_sha256':sha(reconstructed.encode())}
    return blocks,tables,elements,coverage

