"""Collect lexical numbering candidates and resolve bounded split notation."""
import re
from .markers import marker
from .split_numbering import annotate_split_numbers
from ..settings import get_config


def format_pattern(m):
    if m['type'].startswith('number') or m['type']=='numeric_path':
        return re.sub(r'\d+','N',m['raw'])
    if m['type'].startswith('hangul'):
        return re.sub('['+re.escape(get_config()['markers']['hangul_alphabet'])+']','한글',m['raw'])
    return m['type']


def collect_candidates(blocks,profile):
    """Lexical candidates only: neither parent nor depth is assigned here."""
    rules=get_config()['hierarchy'];result=[];previous_top=None
    for position,block in enumerate(blocks):
        m=marker(block['text_normalized'],profile) if block['type']!='table' else None
        if m is None:continue
        text=block['text_normalized'];hints=block['format_hints']
        document_title=profile.is_document_title(hints['classes'],text)
        sentence=bool(re.search(profile.sentence_end_pattern,text))
        top_hint=profile.is_top_heading_hint(hints['classes'],block['source_tag'])
        top=not document_title and m['type']=='number_dot' and (top_hint or (
            len(text)<rules['top_title_max_exclusive'] and not sentence and (
                previous_top is None and m['value']==1 or previous_top is not None and m['value']==previous_top+1)))
        if top:previous_top=m['value']
        repeated=bool(result and sentence and not top and
                      result[-1]['marker']==m and result[-1]['decision']!='document_title')
        result.append({'block_id':block['id'],'position':position,'marker':m,
                       'format':m['type'],'pattern':format_pattern(m),'path':m['path'] if m['type']=='numeric_path' else None,
                       'top_hint':top_hint,'is_top':top,'sentence':sentence,
                       'decision':'document_title' if document_title else 'repeated_content' if repeated else 'candidate'})
    annotate_split_numbers(result,blocks,profile)
    return result
