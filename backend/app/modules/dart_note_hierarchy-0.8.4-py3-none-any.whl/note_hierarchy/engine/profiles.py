"""Immutable, injectable document conventions; default rules do not assume DART."""
from dataclasses import dataclass
import re
from ..settings import DEFAULT_CONFIG

@dataclass(frozen=True)
class HtmlProfile:
    name: str = DEFAULT_CONFIG['profiles']['generic']['name']
    root_title: str = DEFAULT_CONFIG['profiles']['generic']['root_title']
    root_role: str = DEFAULT_CONFIG['profiles']['generic']['root_role']
    layout_table_classes: tuple[str,...] = DEFAULT_CONFIG['profiles']['generic']['layout_table_classes']
    layout_table_evidence: str = DEFAULT_CONFIG['profiles']['generic']['layout_table_evidence']
    data_table_evidence: str = DEFAULT_CONFIG['profiles']['generic']['data_table_evidence']
    top_heading_classes: tuple[str,...] = DEFAULT_CONFIG['profiles']['generic']['top_heading_classes']
    top_heading_tags: tuple[str,...] = DEFAULT_CONFIG['profiles']['generic']['top_heading_tags']
    document_title_classes: tuple[str,...] = DEFAULT_CONFIG['profiles']['generic']['document_title_classes']
    document_title_pattern: str | None = DEFAULT_CONFIG['profiles']['generic']['document_title_pattern']
    document_title_evidence: str = DEFAULT_CONFIG['profiles']['generic']['document_title_evidence']
    excluded_marker_prefix_pattern: str | None = DEFAULT_CONFIG['profiles']['generic']['excluded_marker_prefix_pattern']
    max_marker_value: int = DEFAULT_CONFIG['profiles']['generic']['max_marker_value']
    max_unnumbered_heading_length: int = DEFAULT_CONFIG['profiles']['generic']['max_unnumbered_heading_length']
    candidate_exclusions: tuple[str,...] = DEFAULT_CONFIG['profiles']['generic']['candidate_exclusions']
    sentence_end_pattern: str = DEFAULT_CONFIG['profiles']['generic']['sentence_end_pattern']
    top_heading_evidence: str = DEFAULT_CONFIG['profiles']['generic']['top_heading_evidence']
    finance_features: bool = DEFAULT_CONFIG['profiles']['generic']['finance_features']
    ignore_noncontent_text: bool = DEFAULT_CONFIG['profiles']['generic']['ignore_noncontent_text']

    def is_document_title(self,classes,text):
        return bool(self.document_title_pattern and any(c in classes for c in self.document_title_classes) and re.search(self.document_title_pattern,text))

    def is_top_heading_hint(self,classes,tag):
        return any(c in classes for c in self.top_heading_classes) or tag in self.top_heading_tags

GENERIC_PROFILE=HtmlProfile()
