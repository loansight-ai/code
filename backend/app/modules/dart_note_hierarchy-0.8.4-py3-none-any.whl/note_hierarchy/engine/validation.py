from collections import Counter

def validate(blocks,nodes,coverage):
    ids={n['id']:n for n in nodes}; bids={b['id'] for b in blocks}; seen=set(); errors=[]
    for n in nodes:
        if n['parent_id'] is not None:
            p=ids[n['parent_id']]
            if p['id'] not in seen:errors.append('parent_not_before_child:'+n['id'])
            if p['level'] is not None and n['level']!=p['level']+1:errors.append('level:'+n['id'])
        seen.add(n['id'])
    ownership=Counter()
    for n in nodes:
        if n['source_block_id']:ownership[n['source_block_id']]+=1
        ownership.update(n['content_block_ids'])
    if set(ownership)!=bids or any(v!=1 for v in ownership.values()):errors.append('block_ownership_not_exactly_once')
    if not coverage['normalized_text_equal']:errors.append('text_coverage_mismatch')
    if errors:raise AssertionError(errors)
    return {'structural_checks_passed':True,'semantic_accuracy_measured':False,'errors':errors}

