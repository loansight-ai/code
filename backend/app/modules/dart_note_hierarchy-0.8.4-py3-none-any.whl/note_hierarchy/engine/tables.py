"""Generic table units: source headings and contiguous sibling paragraphs, no financial vocabulary."""
from lxml import html
from .metrics import table_shape,attach_content_metrics
from .table_context import neighbor_block_ids, breadcrumb

def extract_table_units(data,root):
    blocks=data['blocks'];nodes={n['id']:n for n in data['nodes']};units=[];shapes={}
    for i,b in enumerate(blocks):
        if b['type']!='table':continue
        element=root.xpath(b['source_xpath'])[0];shapes[b['id']]=table_shape(element)
        owner=nodes[b['owner_node_id']]
        pre,post,_=neighbor_block_ids(blocks,i,owner['id'])
        crumbs=breadcrumb(owner,nodes)
        units.append({'id':'tbl_'+b['id'],'table_block_id':b['id'],'owner_node_id':owner['id'],
            'source_xpath':b['source_xpath'],'shape':shapes[b['id']],'display_title':owner.get('marker_raw','')+' '+owner['title'],
            'title_source':'item_heading_fallback','title_block_id':owner['source_block_id'],'breadcrumb':crumbs,
            'before_block_ids':pre,'after_block_ids':post,'shared_before_block_ids':[],'shared_after_block_ids':[],
            'review_flags':['주변 문맥은 같은 항목 내 연속 문단으로 추정'],'context_status':'heuristic_needs_review',
            'raw_table_html':html.tostring(element,encoding='unicode',with_tail=False),'html_file':'tables/tbl_'+b['id']+'.html','group_id':None})
    attach_content_metrics(data,shapes)
    return units
