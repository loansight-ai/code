"""Active numbering format and last sibling at each resolved depth."""


def path_style(family, raw):
    # N-N, N-N), and (N-N) are not interchangeable sibling styles.
    return family, raw.endswith(')')


class DepthNumberingState:
    def __init__(self):
        self.frames = {}

    def update(self, stack):
        self.frames = {node['level']: node for node in stack if node['level'] is not None}

    def matching_family(self, marker, active_top):
        return [self.frames[depth] for depth in sorted(self.frames, reverse=True)
                if self.frames[depth]['id'] != active_top
                and self.frames[depth].get('marker_family') == marker['family']]

    def path_sibling(self, marker):
        """Require same format and entire parent path before testing ordinal order."""
        candidates = []
        for depth in sorted(self.frames, reverse=True):
            node = self.frames[depth]
            if node.get('marker_type') != 'numeric_path':
                continue
            if path_style(node['marker_family'], node['marker_raw']) != path_style(marker['family'], marker['raw']):
                continue
            if node['numeric_path'][:-1] != marker['path'][:-1]:
                continue
            if marker['value'] > node['marker_value']:
                candidates.append(node)
        consecutive = [node for node in candidates if marker['value'] == node['marker_value']+1]
        if len(consecutive) == 1:
            return consecutive[0]
        if not consecutive and len(candidates) == 1:
            return candidates[0]
        return None


def explicit_path_parent(marker, stack, active_top):
    """A full numeric path beats an unrelated local integer with the same value."""
    prefix = marker['path'][:-1]
    if len(prefix) > 1:
        return next((node for node in reversed(stack)
                     if node.get('marker_type') == 'numeric_path'
                     and node.get('numeric_path') == prefix
                     and path_style(node['marker_family'], node['marker_raw']) == path_style(marker['family'], marker['raw'])), None)
    local = [node for node in reversed(stack) if node.get('marker_value') == prefix[0]]
    if marker.get('enclosure') == 'parenthesized':
        return next((node for node in local if node['marker_type'] in ('number_paren','number_close')), None)
    top = next((node for node in local if node['id'] == active_top), None)
    if marker.get('separator') == '.':
        return top
    # A plain path 2-1 establishes a branch of top-level 2.; it must not attach
    # to a closer (2). Local 1) -> 1-1) remains valid when top-level is 2.
    if top is not None and not marker['raw'].endswith(')'):
        return top
    return next((node for node in local if node['marker_type'] in ('number_close','number_paren','number_dot')), None)
