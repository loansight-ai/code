from pathlib import Path
import re,json,hashlib,os

def norm(s):return re.sub(r'\s+','',s)


def clean(s):return re.sub(r'\s+',' ',s).strip()


def sha(raw):return hashlib.sha256(raw).hexdigest()


def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def relurl(target,origin):return Path(os.path.relpath(target,origin)).as_posix()


