"""Propose unnumbered headings without inserting them into the inferred tree."""
import re
from .markers import marker
from .profiles import GENERIC_PROFILE
from ..settings import get_config

def find_unnumbered_headings(blocks,nodes,profile=GENERIC_PROFILE):
    """Review proposals only: logical line != a measured browser display line."""
    rules=get_config()["hierarchy"]
    byid={n['id']:n for n in nodes};result=[];first_block={}
    for b in blocks:first_block.setdefault(b['source_xpath'],b['id'])
    for i,b in enumerate(blocks):
        text=b['text_normalized'];owner=byid[b['owner_node_id']]
        if b['type']!='paragraph' or b['source_tag'] not in ('p','h1','h2','h3','h4','h5','h6') or b.get('heading_node_id') or owner['id']=='root' or marker(text,profile):continue
        if not rules['min_heading_characters']<=len(text)<=profile.max_unnumbered_heading_length or not re.search('[가-힣A-Za-z]',text):continue
        if b.get('source_element_nonempty_segments',1)>1 and first_block[b['source_xpath']]!=b['id']:continue
        if re.search(rules['unnumbered_sentence_end_pattern'],text):continue
        if re.search(r'[.!?。！？]\s*$',text) or len(re.findall(r'[.!?。！？]\s+',text))>0:continue
        if any(re.search(pattern,text) for pattern in profile.candidate_exclusions):continue
        after=blocks[i+1] if i+1<len(blocks) else None
        if after is None or after.get('heading_node_id') or after['owner_node_id']!=owner['id']:continue
        evidence=['단독 논리 줄/BR 구간의 짧은 비서술형 텍스트'];flags=['실제 화면 한 줄 여부는 미측정','부모·범위 확인 전, 계층에 자동 삽입하지 않음']
        styles=b['format_hints']['inline_styles'];bold=b['format_hints']['bold_tag'] or any('bold' in s or re.search(r'font-weight\s*:\s*[7-9]00',s) for s in styles)
        if bold:evidence.append('굵은 글자 서식')
        if b['source_tag'].startswith('h'):evidence.append('HTML heading 태그')
        following=after['text_normalized'];explains=after['type']!='table' and (len(following)>=rules['following_explanation_min_characters'] or bool(re.search(rules['following_sentence_end_pattern'],following)))
        kind='table_caption' if after['type']=='table' else 'subheading'
        if after['type']=='table':evidence.append('바로 다음에 데이터 표');flags.append('본문 세부 제목과 표 제목의 구분 필요')
        elif explains:evidence.append('동일 항목 안에서 설명 문단이 뒤따름')
        else:continue
        proposal={'id':f'uh{len(result)+1:05d}','block_id':b['id'],'text':text,'candidate_type':kind,
            'proposed_parent_id':owner['id'],'proposed_level':owner['level']+1 if owner['level'] is not None else None,
            'confidence':'medium' if bold and explains else 'low','evidence':evidence,'review_flags':flags,
            'status':'candidate_only','source_xpath':b['source_xpath'],'segment':b.get('segment')}
        b['subheading_candidate']=proposal;result.append(proposal)
    return result
