"""Strategy facade; legacy function imports remain available."""
from .profiles import GENERIC_PROFILE
from .sequential import infer_sequential
from .heading_candidates import find_unnumbered_headings
from ..settings import get_config


def infer(blocks,profile=GENERIC_PROFILE):
    if get_config()['hierarchy']['strategy']=='sequential':
        return infer_sequential(blocks,profile)
    from .top_down import infer_top_down
    return infer_top_down(blocks,profile)
