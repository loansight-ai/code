"""Collect first, partition bounded sibling lists, then recursively resolve children.

No company-specific vocabulary or universal format-to-depth ranking. Models belong
to a particular parent range. Source order is used for content ownership only after
the candidate relations have been decided.
"""
from .profiles import GENERIC_PROFILE
from ..settings import get_config
from .candidates import collect_candidates, format_pattern
from .partial_relations import preserve_partial_relations


def signature(m):
    return (m['family'],m['raw'].endswith(')'),tuple(m.get('path',[])[:-1]) if m['type']=='numeric_path' else ())


def integer_variant(a,b):
    return {a['type'],b['type']}=={'number_paren','number_close'}


class RangeResolver:
    def __init__(self,candidates,blocks):
        self.candidates=candidates;self.blocks=blocks;self.relations={};self.models=[]
        self.rules=get_config()['hierarchy']

    def block(self,index):return self.blocks[self.candidates[index]['position']]
    def mark(self,index):return self.candidates[index].get('inference_marker',self.candidates[index]['marker'])

    def compatible(self,first,index):
        a,b=self.mark(first),self.mark(index)
        return signature(a)==signature(b) or (self.rules['allow_integer_enclosure_variants'] and integer_variant(a,b))

    def siblings(self,start,end):
        """Look ahead within this parent range before accepting alternate notation.

        An exact-format continuation takes precedence over a nested list that uses
        another enclosure. Regressing ordinals and deeper layout tables do not
        establish new siblings without a separate parent boundary.
        """
        chosen=[start];last=start;base=self.mark(start);base_ctx=self.block(start)['table_context'];child_styles=set()
        for index in range(start+1,end):
            if not self.compatible(start,index):continue
            ctx=self.block(index)['table_context']
            m=self.mark(index);last_m=self.mark(last)
            if signature(m)!=signature(base) and m['value']==1:
                child_styles.add(signature(m))
                continue
            if signature(m)!=signature(base) and signature(m) in child_styles:continue
            if len(ctx)>len(base_ctx) and ctx[:len(base_ctx)]==base_ctx:
                # A single item can be wrapped in a layout table without being
                # a child: require both neighbouring ordinals outside the wrapper.
                exact_later=[self.mark(j)['value'] for j in range(index+1,end)
                    if signature(self.mark(j))==signature(base) and self.block(j)['table_context']==base_ctx]
                bridge=(signature(m)==signature(base) and m['value']==last_m['value']+1
                        and m['value'] not in exact_later and m['value']+1 in exact_later)
                if not bridge:continue
            if m['value']<last_m['value'] or m['value']==last_m['value']==1:
                if signature(base)==signature(m):break
                continue
            if signature(base)!=signature(m):
                if m['value']!=last_m['value']+1:continue
                # A later exact-format candidate at this ordinal is stronger than
                # an alternate enclosure inside a child list.
                exact=any(signature(self.mark(j))==signature(base) and
                          self.mark(j)['value']==m['value'] and
                          self.block(j)['table_context']==base_ctx for j in range(index+1,end))
                if exact:continue
                # Require another member to support an enclosure transition.
                supported=len(chosen)>1 or any(self.compatible(start,j) and
                            self.mark(j)['value']==m['value']+1 for j in range(index+1,end))
                if not supported:continue
            chosen.append(index);last=index
            child_styles.clear()
        return chosen

    def resolve(self,start,end,parent,parent_marker=None,forbidden=()):
        if start>=end:return
        # Explicit paths can establish a boundary even after introductory lists.
        # A leading (1)/(2) must not capture a later plain path 2-1 of top 2.
        if parent_marker:
            prefix=parent_marker['path'] if parent_marker['type']=='numeric_path' else [parent_marker['value']]
            anchor=next((i for i in range(start,end) if self.mark(i)['type']=='numeric_path'
                and self.mark(i)['path'][:-1]==prefix
                and (parent_marker['type']=='numeric_path' or
                     parent_marker['type']=='number_dot' and self.mark(i)['enclosure']=='plain' and not self.mark(i)['raw'].endswith(')'))),None)
            if anchor is not None and anchor>start:
                self.resolve(start,anchor,parent,parent_marker,forbidden)
                self.resolve(anchor,end,parent,parent_marker,forbidden)
                return
        first=self.mark(start);sig=signature(first)
        indices=self.siblings(start,end)
        ctx=self.block(start)['table_context']
        blocked=any(sig==old_sig and not (len(ctx)>len(old_ctx) and ctx[:len(old_ctx)]==list(old_ctx))
                    for old_sig,old_ctx in forbidden)
        flags=[];established=True
        if blocked:
            established=False
            flags=['같은 형식의 번호 재시작: 범위 경계 미확정']
        elif first['type']=='numeric_path':
            prefix=first['path'][:-1]
            actual=(parent_marker.get('path') if parent_marker and parent_marker['type']=='numeric_path'
                    else [parent_marker['value']] if parent_marker else [])
            appropriate=parent_marker and prefix==actual
            if appropriate and first.get('enclosure')=='parenthesized':
                appropriate=parent_marker['type'] in ('number_paren','number_close','numeric_path')
            if not appropriate:
                established=False;flags.append('숫자 경로의 부모 접두사 미발견')
        elif first['value']!=1:
            # Missing initial items can be inferred only from an observed run.
            established=parent is not None and len(indices)>1 and self.mark(indices[1])['value']==first['value']+1
            flags.append('목록의 시작 번호 누락' if established else '선행 동일 형식 항목/시작 번호 미발견')
        if parent is None:established=False
        scope_id=f'scope{len(self.models)+1:05d}'
        model={'id':scope_id,'parent_candidate':parent,'start_block_id':self.candidates[start]['block_id'],
               'end_block_id':self.candidates[end-1]['block_id'],
               'formats':sorted({self.candidates[i]['marker']['type'] for i in indices}),
               'patterns':sorted({format_pattern(self.candidates[i]['marker']) for i in indices}),
               'ordinals':[self.mark(i)['value'] for i in indices],
               'member_block_ids':[self.candidates[i]['block_id'] for i in indices],
               'status':'inferred' if established else 'unresolved','evidence':['부모 범위 전체의 형식·번호 흐름 비교']}
        self.models.append(model)
        for offset,index in enumerate(indices):
            m=self.mark(index);local_flags=list(flags) if offset==0 else []
            if offset:
                prev=self.mark(indices[offset-1])
                split_continuation=m.get('split_index',0)==prev.get('split_index',0)+1 and m['value']==prev['value']
                if m['value']==prev['value']:
                    if not split_continuation:local_flags.append('같은 목록의 번호 중복')
                elif m['value']!=prev['value']+1:local_flags.append('같은 목록의 번호 건너뜀')
                if signature(m)!=signature(prev):local_flags.append('같은 목록의 괄호 표기 전환')
            self.relations[index]={'parent':parent if established else None,'scope_id':scope_id,
                'flags':local_flags,'evidence':['부모 범위 안의 형제 목록 일괄 추론'],
                'relative_parent_confirmed':bool(established)}
            stop=indices[offset+1] if offset+1<len(indices) else end
            # If a parent is ambiguous, its bounded children can still be linked
            # to it. Absolute depth remains unknown; no obsolete sibling stack.
            self.resolve(index+1,stop,index,self.candidates[index]['marker'],forbidden+((sig,tuple(ctx)),))


def infer_top_down(blocks,profile=GENERIC_PROFILE):
    rules=get_config()['hierarchy'];candidates=collect_candidates(blocks,profile)
    active=[c for c in candidates if c['decision'] not in ('document_title','repeated_content')]
    resolver=RangeResolver(active,blocks)
    tops=[i for i,c in enumerate(active) if c['is_top']]
    if tops and tops[0]>0:resolver.resolve(0,tops[0],None)
    if not tops:resolver.resolve(0,len(active),None)
    for number,index in enumerate(tops):
        resolver.relations[index]={'parent':'root','scope_id':None,'flags':[],
            'evidence':[profile.top_heading_evidence if active[index]['top_hint'] else '상위 번호 연속성과 짧은 제목'],
            'relative_parent_confirmed':True}
        resolver.resolve(index+1,tops[number+1] if number+1<len(tops) else len(active),index,active[index]['marker'])
    nodes=[{'id':'root','parent_id':None,'level':0,'role':profile.root_role,'title':profile.root_title,
            'source_block_id':None,'confidence':'high','evidence':['수집 단위'],'content_block_ids':[]}]
    byid={'root':nodes[0]};reviews=[];top=None
    index_to_id={i:f'n{i+1:05d}' for i in range(len(active))}
    for i,c in enumerate(active):
        m=c['marker'];relation=resolver.relations[i];block=blocks[c['position']]
        pid=relation['parent'];parent_id='root' if pid=='root' else index_to_id[pid] if pid is not None else None
        p=byid.get(parent_id);level=p['level']+1 if p and p['level'] is not None else None
        flags=list(relation['flags']);evidence=list(relation['evidence'])
        if parent_id is not None and level is None:flags.append('상위 항목의 깊이가 미확정; 상대 부모 연결 유지')
        if m['type']=='numeric_path' and parent_id and p.get('marker_type')=='number_close' and m.get('enclosure')=='parenthesized':
            flags.append('부모·자식의 괄호 표기 차이: 숫자 경로로 연결')
        role='numbered_item' if c['sentence'] or len(block['text_normalized'])>rules['numbered_item_min_exclusive'] else 'heading'
        if role=='numbered_item':flags.append('번호가 붙은 설명 문장; 독립 제목 여부 검토')
        if level is None:confidence='low'
        elif c['is_top'] and c['top_hint']:confidence='high'
        else:confidence='medium'
        if c['is_top']:top=index_to_id[i]
        node={'id':index_to_id[i],'parent_id':parent_id,'level':level,'role':role,'title':m['title'],
              'marker_raw':m['raw'],'marker_type':m['type'],'marker_family':m['family'],'marker_value':m['value'],
              'numeric_path':m['path'] if m['type']=='numeric_path' else None,'source_block_id':c['block_id'],
              'source_xpath':block['source_xpath'],'confidence':confidence,'table_context':block['table_context'],
              'evidence':evidence,'review_flags':flags,'content_block_ids':[], 'context_top_node_id':top,
              'status':'unresolved' if parent_id is None else 'relative_only' if level is None else 'inferred',
              'numbering_scope_id':relation['scope_id'],'relative_parent_confirmed':relation['relative_parent_confirmed']}
        if c.get('numbering_interpretation')=='split_sibling':
            node['numbering_interpretation']='split_sibling'
            node['sequence_value']=c['inference_marker']['value'];node['split_index']=c['inference_marker']['split_index']
            node['split_evidence']=c['split_evidence']
            node['evidence'].append(c['split_evidence']['evidence'])
        node['display_level']=level if level is not None else (
            p['display_level']+1 if p else byid[top]['display_level']+1 if top else 1)
        nodes.append(node);byid[node['id']]=node;c.update(decision=role,node_id=node['id'],scope_id=relation['scope_id'])
        if flags:reviews.append({'node_id':node['id'],'block_id':c['block_id'],'text':block['text_normalized'],
                                'flags':flags,'confidence':confidence})
    for model in resolver.models:
        parent=model.pop('parent_candidate');proposed=index_to_id[parent] if isinstance(parent,int) else parent
        model['proposed_parent_node_id']=proposed
        model['parent_node_id']=proposed if model['status']=='inferred' else None
        parent_node=byid.get(proposed,nodes[0])
        parent_node.setdefault('child_numbering_models',[]).append(model)
        model['depth']=parent_node['level']+1 if model['parent_node_id'] is not None and parent_node['level'] is not None else None
        if model['depth'] is None and model['status']=='inferred':model['status']='relative_only'
    split_tops={}
    for index,c in enumerate(active):
        if c.get('split_group_id') and c['is_top']:split_tops.setdefault(c['split_group_id'],[]).append(index)
    for key,indices in split_tops.items():
        model={'id':'top_'+key,'parent_node_id':'root','proposed_parent_node_id':'root','depth':1,
            'start_block_id':active[indices[0]]['block_id'],'end_block_id':active[indices[-1]]['block_id'],
            'formats':['numeric_path'],'patterns':sorted({format_pattern(active[i]['marker']) for i in indices}),
            'ordinals':[resolver.mark(i)['value'] for i in indices],
            'member_block_ids':[active[i]['block_id'] for i in indices],'status':'inferred',
            'evidence':['앞뒤 상위 번호 사이의 같은 레벨 분할 번호']}
        nodes[0].setdefault('child_numbering_models',[]).append(model);resolver.models.append(model)
        for i in indices:byid[index_to_id[i]]['numbering_scope_id']=model['id']
    preserve_partial_relations(nodes,resolver.models)
    # Resolve block ownership after the entire tree has been inferred.
    headings={n['source_block_id']:n for n in nodes[1:]};owner=nodes[0]
    for block in blocks:
        if block['id'] in headings:
            owner=headings[block['id']];block['heading_node_id']=owner['id']
        else:owner['content_block_ids'].append(block['id'])
        block['owner_node_id']=owner['id']
    return nodes,candidates,reviews
