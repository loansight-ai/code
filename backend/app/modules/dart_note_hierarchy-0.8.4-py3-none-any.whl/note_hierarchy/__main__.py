"""python -m note_hierarchy input.html --profile dart --output result"""
import argparse,json
from . import DocumentProcessor,__version__

def main():
    parser=argparse.ArgumentParser(description='Extract hierarchy and review HTML from one document; no API/network access.')
    parser.add_argument('--version',action='version',version='note_hierarchy '+__version__)
    parser.add_argument('input',help='HTML input file')
    parser.add_argument('--profile',choices=['generic','dart'],default='generic')
    parser.add_argument('--output',required=True,help='Output directory')
    parser.add_argument('--document-id')
    parser.add_argument('--config',help='JSON rule overrides; omitted keys retain bundled defaults')
    parser.add_argument('--encoding',default='utf-8',help='Input byte encoding, default UTF-8')
    parser.add_argument('--title')
    parser.add_argument('--period',help='Reporting period label, for example 2025.12')
    parser.add_argument('--kind',help='Document label, for example 연결 or 별도')
    parser.add_argument('--base-url',help='Optional base URI for CSS/images in the rendered copy')
    parser.add_argument('--link-periods',action='store_true',help='Financial profile only: link current/prior tables using same-axis labels')
    args=parser.parse_args()
    processor=DocumentProcessor(args.profile,link_periods=args.link_periods,encoding=args.encoding,config=args.config)
    metadata={'title':args.title or args.document_id or args.input}
    if args.period is not None:metadata['period']=args.period
    if args.kind is not None:metadata['kind']=args.kind
    result=processor.process_file(args.input,document_id=args.document_id,metadata=metadata)
    paths=result.write(args.output,base_url=args.base_url)
    print(json.dumps({k:str(v) for k,v in paths.items()},ensure_ascii=False))

if __name__=='__main__':main()
