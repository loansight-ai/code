from html import escape

def render_period_group(link,lookup):
    panels=[]
    for uid in link['table_ids']:
        unit=lookup[uid];label=link['periods'][uid]['label']
        panels.append('<section><h2>'+escape(label)+'</h2><iframe title="'+escape(label,quote=True)+'" src="../'+unit['html_file']+'"></iframe></section>')
    details=''
    if link.get('matching'):
        m=link['matching'];status={'matched':'매칭','needs_review':'검토 필요','unmatched':'불일치'}[link['match_status']]
        details='<aside><h2>주제 제목 연결: '+status+'</h2><p>같은 직속 계층 · 연속한 데이터 표 · 당기→전기. 행은 행끼리, 열은 열끼리 비교하며 전치는 검사하지 않음. 제목 연결과 항목 대응은 별개이며 셀의 값 대응·물리적 병합은 수행하지 않음.</p>'
        if link.get('item_correspondence'):
            item=link['item_correspondence'];item_names={'aligned_labels':'양 축 라벨 대응 근거 있음','partial_labels':'일부 라벨만 대응','unresolved':'항목 대응 미확정'}
            details+='<p><b>항목 대응:</b> '+item_names[item['status']]+' · 금액 셀의 일대일 대응·단위 환산은 수행하지 않음</p>'
            for uid in link['table_ids']:
                p=link['periods'][uid]
                details+='<details><summary>'+escape(p['label'])+' 표의 기간 역할·머리글</summary><p>전체 표 기간: '+escape(p['label'])+' ('+escape(p['basis'])+')</p>'
                for cell in p.get('internal_periods',[]):
                    details+='<div>행 '+str(cell['row']+1)+' · 열 '+str(cell['col']+1)+' · '+escape(cell['label'])+' → '+escape(cell['semantic_role'])+'</div>'
                axis=m['current_axes'] if p['role']=='current' else m['prior_axes']
                details+='<p>머리글 '+str(axis.get('header_rows_inferred',0))+'행 · 근거: '+escape(', '.join(axis.get('header_evidence',[])))+'</p></details>'
        for key,name in [('rows','행 라벨'),('columns','열 라벨')]:
            axis=m[key];coverage=axis['smaller_side_coverage']
            details+='<p><b>'+name+'</b> · 공통 '+str(axis['shared_count'])+'개 / 당기 '+str(axis['left_count'])+'개 / 전기 '+str(axis['right_count'])+'개 · 작은 쪽 포함률 '+(f'{coverage:.0%}' if coverage is not None else '비교 불가')+'</p><details><summary>일치·차이 라벨</summary><p>공통: '+escape(' | '.join(axis['shared']))+'</p><p>당기만: '+escape(' | '.join(axis['only_current']))+'</p><p>전기만: '+escape(' | '.join(axis['only_prior']))+'</p></details>'
        details+='<p>검토 근거: '+escape('; '.join(link['review_flags']) or '없음')+'</p><p>머리글과 행 라벨은 규칙 기반 추정이며 의미 정확도는 별도 검증 대상.</p></aside>'
    return '<!doctype html><html lang="ko"><meta charset="utf-8"><title>'+escape(link['common_title'])+'</title><style>body{font:14px/1.6 sans-serif;margin:24px}.panels{display:grid;grid-template-columns:1fr 1fr;gap:16px}aside{padding:12px;background:#edf2f7}iframe{width:100%;height:80vh;border:1px solid #ccc}@media(max-width:800px){.panels{grid-template-columns:1fr}}</style><h1>'+escape(link['common_title'])+'</h1><p>공통 제목 후보 · 기간과 원본 표 유지 · 규칙 기반 추론</p>'+details+'<div class="panels">'+''.join(panels)+'</div></html>'

def render_unit(unit,blocks):
    before=set(unit['before_block_ids']+unit['shared_before_block_ids']);after=set(unit['after_block_ids']+unit['shared_after_block_ids'])
    def paragraphs(ids):
        return ''.join('<p data-source-block="'+b['id']+'">'+escape(b['text'])+'</p>' for b in blocks if b['id'] in ids)
    breadcrumb=' → '.join(x['text'] for x in unit['breadcrumb'])
    # The serialized table fragment is unchanged; context is a plain-text derivative.
    period=('<p><strong>'+escape(unit['period_label'])+'</strong> · <a href="../period_groups/'+unit['period_title_link_id']+'.html">같은 제목의 당기·전기 표 보기</a></p>') if unit.get('period_title_link_id') else ''
    return '<!doctype html><html lang="ko"><meta charset="utf-8"><title>'+escape(unit['display_title'])+'</title><style>body{font:14px/1.6 sans-serif;margin:24px}table{border-collapse:collapse}td,th{border:1px solid #aaa;padding:5px}header{background:#edf2f7;padding:12px}.context{border-left:3px solid #ccc;padding-left:12px}small{color:#666}</style><header><b>'+escape(unit['display_title'])+'</b>'+period+'<br>'+escape(breadcrumb)+'<br><small>원문 표 + 주변 문맥 추론 초안. 제목 출처: '+unit['title_source']+' · '+escape('; '.join(unit['review_flags']))+'</small></header><section class="context">'+paragraphs(before)+'</section><section id="target-table">'+unit['raw_table_html']+'</section><section class="context">'+paragraphs(after)+'</section><p><small>원문 위치: '+escape(unit['source_xpath'])+'</small></p></html>'

