from html import escape
from lxml import html,etree
from ..engine.common import relurl

def review_page(path,note,nodes,blocks,source_root):
    bmap={b['id']:b for b in blocks}; rows=[];nmap={n['id']:n for n in nodes}
    heading_proposals={}
    for b in blocks:
        if b.get('subheading_candidate'):
            p=b['subheading_candidate'];heading_proposals.setdefault(p['proposed_parent_id'],[]).append(p)
    source=source_root/note['local_view_html']
    for n in nodes[1:]:
        b=bmap[n['source_block_id']]; indent=min(n.get('display_level',n['level'] or 1),10)*18
        label=escape(n['marker_raw']+' '+n['title']); flags='; '.join(n['review_flags'])
        if n['parent_id'] is None and n.get('known_ancestor_ids'):
            ancestors=[nmap[i] for i in n['known_ancestor_ids'] if i!='root']
            if ancestors:
                label+=' <small style="color:#176447">[상위 소속: '+escape(' → '.join(a['marker_raw']+' '+a['title'] for a in ancestors))+' / 직접 부모만 미확정]</small>'
        if n.get('sibling_group_id'):
            neighbours=[nmap[i]['marker_raw'] for i in (n.get('previous_sibling_id'),n.get('next_sibling_id')) if i]
            if neighbours:label+=' <small>[같은 목록: '+escape(' · '.join(neighbours))+']</small>'
        models=n.get('child_numbering_models',[])
        if models:
            label+=' <small>[하위 형식: '+escape(' / '.join(', '.join(m.get('patterns',m['formats'])) for m in models))+']</small>'
        table_links=''
        if n.get('content_metrics'):
            direct=n['content_metrics']['direct']; total=n['content_metrics']['subtree']
            label+=f' <strong style="font-size:12px;color:#176447">[전체: 본문 {total["narrative_characters"]:,}자 · 표 {total["table_count"]}개 / 직속: 본문 {direct["narrative_characters"]:,}자 · 표 {direct["table_count"]}개]</strong>'
            units=n.get('subtree_table_unit_ids',[])
            if units:
                table_links='<details><summary>포함된 표·주변 해설 보기</summary>'+''.join(f'<div><a href="tables/{uid}.html" target="source">{uid}</a></div>' for uid in units)+'</details>'
        if n.get('period_title_link_ids'):
            table_links+='<details open><summary>같은 제목의 당기·전기 표</summary>'+''.join('<div><a href="period_groups/'+lid+'.html" target="_blank">당기·전기 표 비교 · '+lid+'</a></div>' for lid in n['period_title_link_ids'])+'</details>'
        if n.get('period_table_candidates'):
            status_labels={'matched':'매칭','needs_review':'검토 필요','unmatched':'불일치'}
            table_links+='<details open><summary>당기→전기 표 후보 · 행/열 라벨 비교</summary>'+''.join(
                '<div><a href="'+escape(c['html_file'],quote=True)+'" target="_blank">['+status_labels[c['match_status']]+'] '+escape(c['common_title'])+'</a></div>'
                for c in n['period_table_candidates'])+'</details>'
        proposals=heading_proposals.get(n['id'],[])
        proposal_html=('<details open><summary>번호 없는 제목 후보 '+str(len(proposals))+'개 · 확정 트리/통계 미반영</summary>'+''.join('<div class="proposal" id="candidate-'+p['id']+'"><span>↳ [후보]</span> <a href="source.html#'+p['block_id']+'" target="source">'+escape(p['text'])+'</a><br><small>'+('표 제목 후보' if p['candidate_type']=='table_caption' else '세부 제목 후보')+' · 제안 depth='+str(p['proposed_level'])+' · '+p['confidence']+'</small><br><small>'+escape('; '.join(p['evidence']))+'</small></div>' for p in proposals)+'</details>') if proposals else ''
        rows.append(f'<div class="node {n["confidence"]}" data-unresolved="{str(n["level"] is None).lower()}" data-block="{n["source_block_id"]}" style="margin-left:{indent}px"><a href="source.html#{n["source_block_id"]}" target="source" title="{escape(b["source_xpath"],quote=True)}">{label}</a> <small>{escape(n["id"])} · level={n["level"]} · {n["confidence"]} · parent={n["parent_id"]}</small>{table_links}{proposal_html}<details><summary>판단 근거·검토</summary>{escape("; ".join(n["evidence"]))}<br>{escape(flags)}<p>{escape(b["source_xpath"])}</p></details></div>')
    page='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>주석 계층 검토</title><style>body{font:14px/1.6 sans-serif;margin:0}header{padding:12px;background:#edf2f7}main{display:grid;grid-template-columns:50% 50%;height:86vh}aside{overflow:auto;padding:10px}iframe{width:100%;height:100%;border:0}.node{padding:5px;border-bottom:1px solid #eee}.low{background:#fff1e8}.medium{background:#fffdf2}small{color:#666}a{color:#174e8a}summary{cursor:pointer}details{font-size:12px}</style>'''
    page+=f'<header><b>{escape(note["company"])} · {escape(note["period"])} · {escape(note["kind"])}</b><br>규칙 기반 초안입니다. high는 규칙 근거 강도를 뜻하며 정확도 확률이 아닙니다. 주황색은 부모/범위 확인이 필요합니다. 제목을 누르면 오른쪽 원문 위치로 이동합니다. <a href="{escape(relurl(source,path.parent),quote=True)}" target="_blank">수집본 열기</a></header><main><aside>'+''.join(rows)+'</aside><iframe name="source" src="source.html"></iframe></main></html>'
    proposals=[p for values in heading_proposals.values() for p in values]
    availability=('<p><strong>번호 없는 제목 후보 '+str(len(proposals))+'개</strong> · <a href="#candidate-'+proposals[0]['id']+'">첫 후보로 이동</a> · 점선 영역의 [후보]는 검토 전이며 확정 계층과 통계에 미반영</p>') if proposals else '<p><strong>이 문서의 번호 없는 제목 후보는 0개입니다.</strong> 번호가 있는 항목만 추론 트리에 표시됩니다.</p>'
    page=page.replace('</style>','.proposal{margin:8px 0 8px 22px;padding:8px 12px;border-left:3px dashed #b47b22;background:#fff7e6;scroll-margin-top:12px}.proposal:target{outline:2px solid #b47b22}</style>',1).replace('</header>',availability+'</header>',1)
    unresolved_count=sum(n['level'] is None for n in nodes[1:])
    toolbar='<div style="padding:12px;background:#fff4de;border:1px solid #deb66b"><b>지금 확인할 항목: 부모 미확정 '+str(unresolved_count)+'개</b> <label style="margin-left:14px"><input type="checkbox" id="only-unresolved"> 미확정만 보기</label> <button id="first-unresolved" type="button">첫 미확정 원문으로</button><div style="font-size:12px">번호 없는 제목 후보는 별도 제안입니다. 부모 미확정 항목과 구분해서 확인하세요.</div></div>'
    page=page.replace('<main>',toolbar+'<main>',1)
    page=page.replace('</html>',"""<script>(()=>{const toggle=document.getElementById('only-unresolved');const rows=[...document.querySelectorAll('.node')];function apply(){rows.forEach(row=>row.hidden=toggle.checked&&row.dataset.unresolved!=='true')}document.getElementById('first-unresolved').onclick=()=>{toggle.checked=true;apply();let row=rows.find(r=>r.dataset.unresolved==='true');if(row){document.querySelector('iframe[name=source]').src='source.html#'+row.dataset.block;row.scrollIntoView({block:'nearest'})}};toggle.onchange=apply;if(location.hash==='#unresolved')document.getElementById('first-unresolved').click()})();</script></html>""",1)
    if note.get('profile_name') and note['profile_name']!='dart':page=page.replace('주석 계층 검토','문서 계층 검토')
    path.write_text(page,encoding='utf-8')


def annotate(path,note,root,blocks,elements,source_root):
    # Annotated derivative; untouched raw response remains in SRC and SHA is in JSON.
    for selector, attribute in [('link', 'href'), ('img', 'src')]:
        for element in root.xpath('//'+selector+'[@'+attribute+']'):
            resource=next((r for r in note.get('resources',[]) if r.get('status')=='ok' and r['url'].endswith(element.get(attribute,''))),None)
            if resource:element.set(attribute,relurl(source_root/resource['path'],path.parent))
    annotated=set()
    # Multiple BR segments share an element: stable fragment links point to their common source paragraph.
    for b in blocks:
        if 'heading_node_id' not in b and not b.get('subheading_candidate'):continue
        el=elements[b['id']]
        anchor=etree.Element('a',id=b['id']);anchor.set('class','hierarchy-anchor')
        el.insert(0,anchor)
        if el not in annotated:
            el.set('data-hierarchy-node',b.get('heading_node_id',b.get('subheading_candidate',{}).get('id','')));annotated.add(el)
    head=root.find('head')
    if head is not None:
        charset=etree.Element('meta',charset='utf-8');head.insert(0,charset)
        style=etree.SubElement(head,'style');style.text='.hierarchy-anchor{scroll-margin-top:30px}.hierarchy-anchor:target{display:block;outline:3px solid #f80}[data-hierarchy-node]:hover{outline:1px dashed #999}'
    path.write_bytes(html.tostring(root,encoding='utf-8',doctype='<!doctype html>'))

