"""Review/source rendering with explicit resource roots."""
