"""Path-independent public API for one HTML document. No network or credentials."""
from dataclasses import dataclass,field
from pathlib import Path
from copy import deepcopy
from lxml import html,etree
from .engine.profiles import HtmlProfile,GENERIC_PROFILE
from .adapters.dart import DART_PROFILE
from .engine.common import sha,dump
from .engine.blocks import extract_blocks
from .engine.hierarchy import infer,find_unnumbered_headings
from .engine.validation import validate
from .engine.tables import extract_table_units
from .rendering.review import review_page,annotate
from .settings import load_config, DEFAULT_CONFIG, processor_rules

PROFILES={'generic':GENERIC_PROFILE,'dart':DART_PROFILE}

@dataclass
class DocumentResult:
    data: dict
    table_units: list
    _root: object=field(repr=False)
    _raw: bytes=field(repr=False)
    _note: dict=field(repr=False)
    source_path: Path | None=None

    def write(self,output_dir,*,resource_root=None,base_url=None):
        """Export JSON, annotated source, tables, and the split review screen."""
        from .rendering.tables import render_unit
        output=Path(output_dir).resolve();output.mkdir(parents=True,exist_ok=True)
        note=dict(self._note);note.setdefault('resources',[])
        note['local_view_html']='source_original.html'
        source_root=Path(resource_root).resolve() if resource_root else output
        clone=deepcopy(self._root)
        head=clone.find('head')
        if head is None:head=etree.Element('head');clone.insert(0,head)
        target=base_url or self.data.get('source_url') or (self.source_path.as_uri() if self.source_path else None)
        if target:
            base=etree.Element('base',href=target);head.insert(0,base)
        # Block IDs map to XPath, so the renderer can annotate the cloned DOM.
        # Inserting a missing head does not change body element paths.
        paths={b['source_xpath'] for b in self.data['blocks']}
        cache={p:clone.xpath(p)[0] for p in paths}
        elements={b['id']:cache[b['source_xpath']] for b in self.data['blocks']}
        (output/'source_original.html').write_bytes(self._raw)
        annotate(output/'source.html',note,clone,self.data['blocks'],elements,source_root)
        # Original-file navigation is local to this export; asset paths stay explicit.
        review_page(output/'review.html',note,self.data['nodes'],self.data['blocks'],output)
        (output/'tables').mkdir(exist_ok=True)
        for unit in self.table_units:(output/unit['html_file']).write_text(render_unit(unit,self.data['blocks']),encoding='utf-8')
        if self.data.get('period_title_links'):
            from .rendering.tables import render_period_group
            (output/'period_groups').mkdir(exist_ok=True)
            lookup={u['id']:u for u in self.table_units}
            for link in self.data['period_title_links']:
                (output/link['html_file']).write_text(render_period_group(link,lookup),encoding='utf-8')
        if self.data.get('period_table_candidates'):
            from .rendering.tables import render_period_group
            (output/'period_candidates').mkdir(exist_ok=True)
            lookup={u['id']:u for u in self.table_units}
            for candidate in self.data['period_table_candidates']:
                (output/candidate['html_file']).write_text(render_period_group(candidate,lookup),encoding='utf-8')
        if 'period_table_candidates' in self.data:
            dump(output/'period_table_candidates.json',{'candidates':self.data['period_table_candidates'],
                'matching_version':self.data['period_matching_version']})
        dump(output/'structure.json',self.data)
        dump(output/'table_units.json',{'document_id':self.data['document_id'],'table_units':self.table_units})
        return {'structure':output/'structure.json','review':output/'review.html','source':output/'source.html','tables':output/'table_units.json'}

class DocumentProcessor:
    def __init__(self,profile='generic',*,link_periods=False,encoding='utf-8',config=None):
        self.config=load_config(config)
        self.profile=HtmlProfile(**dict(self.config['profiles'][profile])) if isinstance(profile,str) else profile
        if not isinstance(self.profile,HtmlProfile):raise TypeError('profile must be a profile name or HtmlProfile')
        if link_periods and not self.profile.finance_features:raise ValueError('Period linking needs a financial profile; generic HTML has no financial period semantics')
        self.link_periods=link_periods
        self.encoding=encoding

    @processor_rules
    def process_html(self,source,*,document_id=None,metadata=None):
        raw=source.encode('utf-8') if isinstance(source,str) else bytes(source)
        # Explicit byte encoding avoids lxml's Latin-1 fallback on UTF-8 HTML without meta.
        root=html.document_fromstring(source) if isinstance(source,str) else html.document_fromstring(raw,parser=html.HTMLParser(encoding=self.encoding))
        blocks,tables,_,coverage=extract_blocks(root,self.profile)
        nodes,candidates,reviews=infer(blocks,self.profile)
        proposals=find_unnumbered_headings(blocks,nodes,self.profile)
        verification=validate(blocks,nodes,coverage)
        meta=dict(metadata or {})
        data={'document_id':document_id or sha(raw)[:16],'profile':self.profile.name,'source_sha256':sha(raw),
              'source_url':meta.get('source_url'),'status':'rule_based_draft_not_gold','coverage':coverage,'verification':verification,
              'blocks':blocks,'tables':tables,'nodes':nodes,'candidates':candidates,'review_queue':reviews,
              'unnumbered_heading_candidates':proposals,'metadata':meta}
        data['hierarchy_strategy']=self.config['hierarchy']['strategy']
        data['numbering_scopes']=[model for node in nodes for model in node.get('child_numbering_models',[])]
        if self.config.sha256 != DEFAULT_CONFIG.sha256:
            data['configuration']={'sha256':self.config.sha256,'settings':self.config.to_dict()}
        if self.profile.finance_features:
            from .finance.context import enrich
            units,_=enrich(data,root)
        else:
            units=extract_table_units(data,root)
            data['table_units']=[{k:v for k,v in u.items() if k!='raw_table_html'} for u in units]
        if self.link_periods:
            from .finance.periods import link_period_tables
            links,rejected=link_period_tables(data,units)
            data['period_title_links']=links;data['period_title_link_rejections']=rejected
            data['table_units']=[{k:v for k,v in u.items() if k!='raw_table_html'} for u in units]
            for n in nodes:n['period_title_link_ids']=[link['id'] for link in links if link['owner_node_id']==n['id']]
        note={'company':meta.get('title',data['document_id']),'period':meta.get('period',''),'kind':meta.get('kind',self.profile.name),
              'profile_name':self.profile.name,'resources':meta.get('resources',[])}
        return DocumentResult(data,units,root,raw,note)

    def process_file(self,path,*,document_id=None,metadata=None):
        source=Path(path).resolve();result=self.process_html(source.read_bytes(),document_id=document_id or source.stem,metadata=metadata)
        result.source_path=source
        return result
