"""DART conventions loaded from the bundled, configurable rule file."""
from ..engine.profiles import HtmlProfile
from ..settings import DEFAULT_CONFIG

DART_PROFILE=HtmlProfile(**dict(DEFAULT_CONFIG['profiles']['dart']))
