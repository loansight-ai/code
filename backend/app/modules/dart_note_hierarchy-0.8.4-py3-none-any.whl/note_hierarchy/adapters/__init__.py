"""Domain-specific configuration, separate from HTML parsing and hierarchy logic."""
