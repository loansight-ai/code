"""Reusable HTML hierarchy API; existing DART scripts remain backward compatible."""
from .api import DocumentProcessor,DocumentResult,PROFILES
from .engine.profiles import HtmlProfile,GENERIC_PROFILE
from .adapters.dart import DART_PROFILE

__version__='0.8.4'
from .settings import load_config,config_scope,RulesConfig,DEFAULT_CONFIG_PATH

__all__=['DocumentProcessor','DocumentResult','HtmlProfile','GENERIC_PROFILE','DART_PROFILE','PROFILES','load_config','config_scope','RulesConfig','DEFAULT_CONFIG_PATH']
