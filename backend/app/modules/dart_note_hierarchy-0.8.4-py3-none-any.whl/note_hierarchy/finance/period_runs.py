"""Conservative one-to-one candidates inside consecutive current/prior runs."""
from collections import Counter
from .table_diff import diff_tables
from ..settings import DEFAULT_CONFIG, get_config

GENERIC=frozenset(DEFAULT_CONFIG['period_runs']['generic_labels'])


def correspondence(left, right):
    """Use ordered labels, never numerical values or document distance."""
    rules=get_config()['period_runs']
    diff = diff_tables(left, right, normalize_headers=True, compare_values=False)
    axes = {}
    safe = True
    for name, field, operations in [('rows', 'rows', 'row_diff'), ('columns', 'headers', 'column_diff')]:
        items = []
        for side in ('current', 'prior'):
            matrix = diff[side]
            values = matrix[field]
            if name == 'columns': values = values[matrix['value_start_column']:]
            items.append([v for v in values if v['key']])
        keys = [[v['key'] for v in values] for values in items]
        equal = [o for o in diff[operations] if o['op'] == 'equal']
        if name == 'columns':
            equal = [o for o in equal if o['current'] >= diff['current']['value_start_column'] and o['prior'] >= diff['prior']['value_start_column']]
        shared = [diff['current'][field][o['current']]['key'] for o in equal if diff['current'][field][o['current']]['key']]
        coverage = min(len(shared)/len(k) if k else 0 for k in keys)
        distinctive = len({k for k in shared if k not in rules['generic_labels']})
        unique = all(max(Counter(k).values(), default=0) <= 1 for k in keys)
        axes[name] = {'current_count':len(keys[0]), 'prior_count':len(keys[1]),
                      'shared_count':len(shared), 'minimum_coverage':coverage,
                      'distinctive_shared':distinctive, 'unique_keys':unique, 'shared':shared}
        for values in items:
            for value in values:
                if any(f['warnings'] for f in value['separated']['features']): safe = False
        # An axis used for acceptance must have unique, nonempty labels.
    r, c = axes['rows'], axes['columns']
    both = r['unique_keys'] and c['unique_keys'] and r['minimum_coverage'] >= rules['minimum_coverage'] and c['minimum_coverage'] >= rules['minimum_coverage'] and (r['distinctive_shared'] >= rules['both_axes_min_distinctive_rows'] or c['distinctive_shared'] >= rules['both_axes_min_distinctive_columns'])
    strong_columns = c['unique_keys'] and c['minimum_coverage'] >= rules['minimum_coverage'] and c['distinctive_shared'] >= rules['strong_columns_min_distinctive']
    # Units are metadata, not identity keys; conflicting or one-sided explicit
    # header units must not silently disappear through normalization.
    for operation in diff['column_diff']:
        if operation['op'] != 'equal': continue
        a = diff['current']['headers'][operation['current']]['separated']['features']
        b = diff['prior']['headers'][operation['prior']]['separated']['features']
        if sorted(u for f in a for u in f['units']) != sorted(u for f in b for u in f['units']): safe = False
    return {'eligible':bool(safe and (both or strong_columns)), 'axes':axes,
            'metadata_safe':safe, 'transpose_checked':False, 'values_compared':False,
            'rule':f"both_axes_{rules['minimum_coverage']*100:g}_percent_or_{rules['strong_columns_min_distinctive']}_distinctive_value_headers_{rules['minimum_coverage']*100:g}_percent"}


def select_period_pairs(data, units, periods):
    """Reserve C{2,} P{2,} runs before the legacy adjacent C/P pass."""
    rules=get_config()['period_runs']
    from .periods import unit_for
    bmap = {b['id']:b for b in data['blocks']}

    def compatible(i, j):
        a, b = units[i], units[j]; p, q = periods[i], periods[j]
        if not p or not q or a['owner_node_id'] != b['owner_node_id']: return False
        if (p['basis'],p['horizon']) != (q['basis'],q['horizon']): return False
        start = bmap[a['table_block_id']]['order']; end = bmap[b['table_block_id']]['order']
        return not any(block.get('heading_node_id') or block['owner_node_id'] != a['owner_node_id'] for block in data['blocks'][start+1:end])

    runs=[]
    for i, p in enumerate(periods):
        if p and runs and compatible(i-1, i) and periods[i-1]['role'] == p['role']:
            runs[-1].append(i)
        else: runs.append([i])
    reserved=set(); pairs=[]; groups=[]
    for current, prior in zip(runs,runs[1:]):
        if len(current)<rules['minimum_run_tables'] or len(prior)<rules['minimum_run_tables']: continue
        if not compatible(current[-1],prior[0]): continue
        if (periods[current[0]]['role'],periods[prior[0]]['role']) != ('current','prior'): continue
        indices=current+prior;reserved.update(indices)
        group={'id':'run_'+units[current[0]]['id'], 'owner_node_id':units[current[0]]['owner_node_id'],
               'current_table_ids':[units[i]['id'] for i in current], 'prior_table_ids':[units[j]['id'] for j in prior],
               'comparisons':[], 'selected_table_pairs':[]}
        eligible=[]
        for i in current:
            for j in prior:
                a,b=units[i],units[j]
                try: evidence=correspondence(a,b)
                except ValueError as error:
                    evidence={'eligible':False,'error':str(error)}
                if unit_for(a,bmap) != unit_for(b,bmap) or periods[i].get('conflicting_header_periods') or periods[j].get('conflicting_header_periods'):
                    evidence['eligible']=False;evidence['context_conflict']=True
                group['comparisons'].append({'table_ids':[a['id'],b['id']], **evidence})
                if evidence['eligible']: eligible.append((i,j,evidence))
        counts_current=Counter(i for i,j,e in eligible);counts_prior=Counter(j for i,j,e in eligible)
        for i,j,evidence in eligible:
            if counts_current[i] != 1 or counts_prior[j] != 1: continue
            metadata={'rule':'consecutive_period_runs_mutual_unique_correspondence', 'group_id':group['id'],
                      'correspondence':evidence, 'mutually_unique':True}
            pairs.append((i,j,metadata));group['selected_table_pairs'].append([units[i]['id'],units[j]['id']])
        selected={t for pair in group['selected_table_pairs'] for t in pair}
        group['unresolved_table_ids']=[units[i]['id'] for i in indices if units[i]['id'] not in selected]
        groups.append(group)
    for i in range(len(units)-1):
        if i in reserved or i+1 in reserved: continue
        pairs.append((i,i+1,{'rule':'consecutive_tables_same_owner_current_then_prior'}))
    return sorted(pairs,key=lambda pair:pair[0]), groups
