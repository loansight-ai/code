"""Conservative common-title links for neighboring current/prior period tables."""
from lxml import html
import hashlib,json,re
from ..settings import get_config

from .period_labels import LABEL, compact, period_label
from ..engine.table_grid import ROW_PATH
from .table_matching import label_axes, compare_labels


def period_for(unit,bmap):
    axes=label_axes(unit)
    cells=axes.get('period_cells',[])
    # A table's outer period and its opening/closing balance cells have different roles.
    # First data-row '전기초' is never a whole-table period inference.
    labels=[p for p in cells if p['is_header']]
    duration=[p for p in labels if p['basis']=='duration']
    if len({p['role'] for p in duration})>1:return None
    for bid in reversed(unit['before_block_ids']):
        result=period_label(bmap[bid]['text_normalized'])
        if result:
            # Explicit current+prior balance columns are a combined table, unless
            # the outer marker establishes a duration movement table.
            if result['basis']!='duration' and len({p['role'] for p in labels if p['basis']=='end'})>1:return None
            conflicts=[p for p in labels if p['basis']==result['basis'] and p['horizon']==result['horizon'] and p['role']!=result['role']]
            return result|{'block_id':bid,'source':'adjacent_label','semantic_role':'table_period',
                          'internal_periods':cells,'conflicting_header_periods':conflicts}
    unique={(p['role'],p['basis'],p['horizon']) for p in labels}
    if len(unique)==1:
        p=labels[0]
        return {k:p[k] for k in ('label','role','basis','horizon')}|{'source':'table_header','block_id':unit['table_block_id'],
            'semantic_role':'table_period','internal_periods':cells,'conflicting_header_periods':[]}
    return None

def unit_marker(text):
    return bool(re.search(get_config()['periods']['unit_marker_pattern'],text))

def footnote(text):
    return bool(re.match(get_config()['periods']['footnote_pattern'],text))

def title_text(text):
    return bool(text.strip() and not period_label(text) and not unit_marker(text) and not footnote(text)
                and re.search(r'[가-힣A-Za-z]',text))

def informative_topic(text):
    t=compact(text)
    t=re.sub(get_config()['periods']['label_pattern'],'',t)
    t=re.sub(get_config()['periods']['informative_remove_pattern'],'',t)
    return len(t)>=get_config()['periods']['informative_min_characters']

def unit_for(unit,bmap):
    values=[]
    for bid in list(dict.fromkeys(unit.get('shared_before_block_ids',[])+unit['before_block_ids'])):
        matches=re.findall(get_config()['periods']['unit_extract_pattern'],bmap[bid]['text_normalized'])
        values.extend(compact(v) for v in matches)
    return sorted(set(values))

def canonical(text):
    t=compact(text)
    t=re.sub(get_config()['periods']['canonical_footnote_pattern'],'',t)
    if period_label(t):t='{PERIOD}'
    t=re.sub(get_config()['periods']['canonical_date_pattern'],'{DATE}',t)
    if re.fullmatch(get_config()['periods']['canonical_numeric_pattern'],t or '#'):return '#'
    return t

def schema(unit):
    root=html.fromstring(unit['raw_table_html']);rows=root.xpath(ROW_PATH)
    if root.xpath('.//table | .//img'):return None
    signature=[]
    for row in rows:
        signature.append([(c.tag,c.get('rowspan','1'),c.get('colspan','1'),canonical(c.text_content())) for c in row if c.tag in ('td','th')])
    return signature

def _shared_topic_evidence(left, right, bmap):
    """Topic evidence is independent of row/column correspondence."""
    topic_evidence=[]
    common_intro=set(bid for bid in left.get('shared_before_block_ids',[])+left['before_block_ids'] if title_text(bmap[bid]['text_normalized'])) & set(bid for bid in right.get('shared_before_block_ids',[])+right['before_block_ids'] if title_text(bmap[bid]['text_normalized']))
    shared_descriptions=[bid for bid in common_intro if not bmap[bid].get('heading_node_id') and informative_topic(bmap[bid]['text_normalized'])]
    captions_equal=left['title_source']=='caption_candidate' and right['title_source']=='caption_candidate' and title_text(left['display_title']) and canonical(left['display_title'])==canonical(right['display_title'])
    if shared_descriptions:topic_evidence.append('동일한 원문 도입문·제목 공유')
    if captions_equal:topic_evidence.append('동일한 독립 제목')
    return topic_evidence


def _common_title(left, right, owner, bmap):
    """Prefer a source caption, then its lead-in, then the owner heading."""
    title_unit=next((u for u in [left,right] if u['title_source']=='caption_candidate' and title_text(u['display_title'])),None)
    if title_unit:
        title=title_unit['display_title'];title_source={'type':'caption_candidate','block_id':title_unit['title_block_id']}
    else:
        bids=list(dict.fromkeys(left.get('shared_before_block_ids',[])+left['before_block_ids']))
        intro=[bid for bid in bids if title_text(bmap[bid]['text_normalized']) and re.search(get_config()['periods']['common_intro_pattern'],bmap[bid]['text_normalized'])]
        if intro:title=bmap[intro[-1]]['text_normalized'];title_source={'type':'shared_intro','block_id':intro[-1]}
        else:title=owner.get('marker_raw','')+' '+owner['title'];title_source={'type':'owner_heading','block_id':owner['source_block_id']}
    return title,title_source


def link_period_tables(data,units):
    bmap={b['id']:b for b in data['blocks']};nodes={n['id']:n for n in data['nodes']};links=[];rejected=[];used=set()
    candidates=[]
    for u in units:
        for key in ['common_title','common_title_id','common_title_source','period_title_link_id','period_role','period_label','period_basis','period_horizon']:
            u.pop(key,None)
        if 'original_display_title' in u:u['display_title']=u['original_display_title'];u['title_source']=u['original_title_source']
    from .period_runs import select_period_pairs
    periods=[period_for(unit,bmap) for unit in units]
    pair_indices,period_runs=select_period_pairs(data,units,periods)
    data['period_table_runs']=period_runs
    for i,j,selection in pair_indices:
        left=units[i];right=units[j]
        if left['id'] in used or right['id'] in used or left['owner_node_id']!=right['owner_node_id']:continue
        p=periods[i];q=periods[j]
        if not p or not q or (p['role'],q['role'])!=('current','prior'):continue
        if (p['basis'],p['horizon'])!=(q['basis'],q['horizon']):continue
        start=bmap[left['table_block_id']]['order'];end=bmap[right['table_block_id']]['order'];between=data['blocks'][start+1:end]
        if any(b.get('heading_node_id') or b['owner_node_id']!=left['owner_node_id'] for b in between):continue
        flags=[]
        if any(re.search(get_config()['periods']['between_intro_pattern'],b['text_normalized']) for b in between):flags.append('중간 도입문: 주제 변경 가능성 검토')
        if any(title_text(b['text_normalized']) or footnote(b['text_normalized']) for b in between):flags.append('표 사이 설명·제목 있음')
        a=unit_for(left,bmap);b=unit_for(right,bmap)
        sig_left=schema(left);sig_right=schema(right)
        comparison=compare_labels(left,right)
        reasons=[]
        if a!=b:reasons.append('단위 다름 또는 한쪽 단위 불명')
        title_conflict=left['title_source']=='caption_candidate' and right['title_source']=='caption_candidate' and title_text(left['display_title']) and title_text(right['display_title']) and canonical(left['display_title'])!=canonical(right['display_title'])
        if title_conflict:reasons.append('독립 표 제목 후보 불일치')
        # Do not accept a stale period label across long explanations or a conflicting header.
        for unit,period in [(left,p),(right,q)]:
            if period['source']=='adjacent_label':
                trailing=[bmap[bid]['text_normalized'] for bid in unit['before_block_ids'] if bmap[bid]['order']>bmap[period['block_id']]['order']]
                if any(title_text(t) for t in trailing):reasons.append('기간 표지와 표 사이 설명: 기간 귀속 검토')
            if period.get('conflicting_header_periods'):reasons.append('전체 표 기간과 동일 역할의 헤더 기간 충돌')
        decision=comparison['decision']
        if selection.get('mutually_unique'):
            decision='matched'
            comparison['run_correspondence']=selection['correspondence']
        if decision=='needs_review' and sig_left is not None and sig_left==sig_right and comparison['rows']['shared_count']+comparison['columns']['shared_count']>0:
            decision='matched'
            comparison['exact_schema_support']=True
        comparison['decision_before_context']=decision
        # Independent topic/title decision; row/column item correspondence is retained
        # separately and need not be complete for two tables to share a title.
        topic_evidence=_shared_topic_evidence(left,right,bmap)
        m=comparison
        generic_columns=set(get_config()['periods']['generic_columns'])
        any_axis=m['rows']['shared_count']>0 or bool(set(m['columns']['shared'])-generic_columns)
        if decision=='needs_review' and topic_evidence and any_axis and not title_conflict:
            decision='matched';topic_evidence.append('부분 항목 대응이나 동일 주제 근거 있음')
        if reasons and decision=='matched':decision='needs_review'
        if a!=b and a and b:decision='unmatched'
        comparison['label_decision']=comparison['decision']
        comparison['decision']=decision
        owner=nodes[left['owner_node_id']]
        title,title_source=_common_title(left,right,owner,bmap)
        link_id='period_'+left['id'];sid=hashlib.sha256(json.dumps(sig_left,ensure_ascii=False).encode()).hexdigest() if sig_left is not None else None
        link={'id':link_id,'owner_node_id':owner['id'],'common_title':title,'common_title_source':title_source,
              'table_ids':[left['id'],right['id']],'periods':{left['id']:p,right['id']:q},'unit_labels':a,
              'schema_sha256':sid,'schema_equal':sig_left is not None and sig_left==sig_right,
              'status':'linked_by_rules' if decision=='matched' else decision,'match_status':decision,
              'matching':comparison,'title_linking':{'status':decision,'topic_evidence':topic_evidence,
                   'scope':'주제 제목만 연결; 개별 행·열·셀 값은 동일시하지 않음'},
              'item_correspondence':comparison['item_correspondence'],
              'candidate_rule':selection['rule'],
              'confidence':'medium',
              'review_flags':list(dict.fromkeys(flags+reasons+([] if a else ['공통 단위 표지 미확인'])+(['공통 제목은 항목명에서 추정'] if title_source['type']=='owner_heading' else []))),
              'evidence':(['당기 연속 묶음→전기 연속 묶음','묶음 내부 행·열 대응이 양방향으로 유일'] if selection.get('mutually_unique') else ['원문 데이터 표 순서가 연속'])+['같은 직속 소속 계층','당기→전기 순서','시점/기간 기준 일치','행 라벨끼리·열 라벨끼리 비교','전치 비교 없음'],
              'html_file':('period_groups/' if decision=='matched' else 'period_candidates/')+link_id+'.html'}
        if selection.get('group_id'):link['period_run_id']=selection['group_id']
        candidates.append(link)
        used.update([left['id'],right['id']])
        if decision!='matched':
            rejected.append({'left':left['id'],'right':right['id'],'periods':[p,q],
                'status':decision,'candidate_id':link_id,'matching':comparison,
                'reasons':reasons or ['행·열 라벨 비교 결과: '+decision]})
            continue
        for u,period in [(left,p),(right,q)]:
            u.setdefault('original_display_title',u['display_title']);u.setdefault('original_title_source',u['title_source'])
            u.update({'display_title':title,'title_source':'period_common_title','common_title':title,'common_title_id':link_id,
                'common_title_source':title_source,'period_title_link_id':link_id,'period_role':period['role'],
                'period_label':period['label'],'period_basis':period['basis'],'period_horizon':period['horizon']})
        links.append(link)
    data['period_table_candidates']=candidates
    data['period_matching_version']='0.4.0'
    for node in data['nodes']:
        node['period_table_candidates']=[{k:c[k] for k in ('id','match_status','common_title','html_file')}
            for c in candidates if c['owner_node_id']==node['id']]
    return links,rejected
