"""Whole-table period labels; independent of matching and context selection."""
import re
from ..engine.common import norm as compact
from ..settings import DEFAULT_CONFIG, get_config

LABEL = DEFAULT_CONFIG['periods']['label_pattern']


def period_label(text):
    rules=get_config()['periods']
    t = compact(text)
    t = re.sub(r'^(?:\(\d+\)|\d+[.)])', '', t)
    t = re.sub(r'^[<〈《\[【(（]+|[>〉》\]】)）:：]+$', '', t)
    if not re.fullmatch(get_config()['periods']['label_pattern'], t):
        return None
    return {'label': t, 'role': 'current' if t.startswith(rules['current_prefix']) else 'prior',
            'basis': 'end' if t.endswith(rules['end_suffix']) else ('begin' if t.endswith(rules['begin_suffix']) else 'duration'),
            'horizon': 'quarter' if rules['quarter_term'] in t else ('half' if rules['half_term'] in t else 'annual')}
