"""Optional financial-table context and period linking."""
