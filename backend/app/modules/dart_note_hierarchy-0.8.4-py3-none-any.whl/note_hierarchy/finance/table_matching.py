"""Same-orientation row/column label evidence; never transpose or merge cells."""
import re
from .period_labels import period_label, compact
from ..engine.table_grid import expand_table
from ..settings import DEFAULT_CONFIG, get_config

IGNORED=frozenset(DEFAULT_CONFIG['matching']['ignored_labels'])
ROW_HEADERS=IGNORED | frozenset(DEFAULT_CONFIG['matching']['row_header_extra_labels'])


def numeric_value(text):
    text=compact(text)
    return bool(text and re.fullmatch(get_config()['matching']['numeric_pattern'],text,re.I))


def text_label(text):
    rules=get_config()['matching']
    text = compact(text)
    text = re.sub(rules['footnote_remove_pattern'], '', text)
    text = re.sub(rules['company_remove_pattern'], '', text)
    if not text or period_label(text) or text in rules['ignored_labels']:
        return ''
    if numeric_value(text):
        return ''
    if re.fullmatch(rules['date_label_pattern'], text):
        return ''
    return text


def label_axes(unit):
    return analyze_table(unit)[0]


def analyze_table(unit):
    """Return unchanged public axis evidence plus the reusable internal grid."""
    layout = expand_table(unit['raw_table_html'])
    if not layout['supported']:
        return {'supported':False, 'reason':layout['reason'], 'rows':[], 'columns':[]}, layout
    return _axes_from_grid(layout), layout


def _axes_from_grid(layout):
    rules=get_config()['matching']
    row_headers=set(rules['ignored_labels']) | set(rules['row_header_extra_labels'])
    grid = layout['grid']
    source_cells = layout['source_cells']
    width = layout['width']
    # Structural header closure: rowspan in an opening header row covers lower header
    # rows even when every cell is TD and the next header row contains no numbers.
    header_count=0;header_evidence=[];span_end=0
    for ri,cells in enumerate(source_cells):
        if ri>=rules['max_header_rows']:break
        if not cells:continue
        has_value=any(numeric_value(c['text']) for c in cells)
        explicit=any(c['in_thead'] or c['tag']=='th' for c in cells)
        full_width_group=len(cells)==1 and cells[0]['colspan']>=width and not period_label(cells[0]['text'])
        if ri==0:
            if has_value and not explicit:break
            accept=True;header_evidence.append('opening_header_row')
        elif ri<span_end and not has_value:
            accept=True;header_evidence.append('opening_rowspan_closure')
        elif explicit and not has_value:
            accept=True;header_evidence.append('thead_or_th')
        elif not has_value and not full_width_group and any(c['colspan']>1 for c in source_cells[ri-1]) and any(c['rowspan']>1 for row in source_cells[:ri] for c in row if c['row']+c['rowspan']>ri):
            accept=True;header_evidence.append('spanning_parent_header')
        else:break
        if accept:
            header_count=ri+1
            span_end=max(span_end,max(c['row']+c['rowspan'] for c in cells))
    # Locate the value area independently of whether a particular row is blank.
    value_cols=[c['col'] for row in source_cells[header_count:] for c in row if numeric_value(c['text'])]
    value_start=min(value_cols) if value_cols else None
    if value_start is None:
        named=[ci for ci in range(width) if any(grid[ri][ci] and text_label(grid[ri][ci]['text'])
               and grid[ri][ci]['text'] not in row_headers for ri in range(header_count))]
        value_start=min(named) if named else min(1,width)
        # Blank leading dimension columns in DART XBRL tables are row paths.
        first_header=grid[0] if grid else []
        nonempty=[ci for ci,c in enumerate(first_header) if c and c['text']]
        if nonempty and nonempty[0]>0:value_start=nonempty[0]
    value_start=max(0,min(value_start,width))
    columns = []
    for ci in range(value_start,width):
        path = []
        for ri in range(header_count):
            item = grid[ri][ci]
            label = text_label(item['text']) if item else ''
            if label and (not path or path[-1] != label):
                path.append(label)
        if path:
            columns.append(' / '.join(path))
    rows = [];row_details=[]
    for ri in range(header_count, len(grid)):
        path = []
        for ci, item in enumerate(grid[ri][:value_start]):
            if not item:
                continue
            text = item['text']
            label = text_label(text)
            if not label:
                # Numeric values end the row-heading path. Empty/ignored labels do not.
                if text and text not in rules['ignored_labels'] and not period_label(text):
                    break
                continue
            if not path or path[-1] != label:
                path.append(label)
        if path:
            # A full-width section label is context, not a measured account row.
            if len(source_cells[ri])==1 and source_cells[ri][0]['colspan']>=width:continue
            label=' / '.join(path);rows.append(label)
            row_details.append({'row':ri,'path':path,'label':label})
    period_cells=[]
    for ri,cells in enumerate(source_cells):
        for cell in cells:
            p=period_label(cell['text'])
            if p:period_cells.append(p|{'row':ri,'col':cell['col'],'is_header':ri<header_count,
                'semantic_role': 'opening_balance' if p['basis']=='begin' else ('closing_balance' if p['basis']=='end' else 'period_axis')})
    return {'supported': True, 'rows': sorted(set(rows)), 'columns': sorted(set(columns)),
            'header_rows_inferred': header_count, 'header_evidence':header_evidence,
            'value_start_column':value_start,'row_details':row_details,'period_cells':period_cells,
            'physical_rows': len(source_cells), 'expanded_columns': width}


def overlap(left, right):
    a, b = set(left), set(right)
    shared = sorted(a & b)
    return {'left_count': len(a), 'right_count': len(b), 'shared_count': len(shared),
        'jaccard': len(shared)/len(a | b) if a | b else None,
        'smaller_side_coverage': len(shared)/min(len(a), len(b)) if a and b else None,
        'shared': shared, 'only_current': sorted(a-b), 'only_prior': sorted(b-a)}


def compare_labels(left, right):
    rules=get_config()['matching']
    a, b = label_axes(left), label_axes(right)
    rows, columns = overlap(a['rows'], b['rows']), overlap(a['columns'], b['columns'])
    # A shared generic amount column alone is too weak to establish the topic.
    row_good = rows['shared_count'] >= 1 and rows['smaller_side_coverage'] >= rules['minimum_coverage']
    col_good = columns['shared_count'] >= 1 and columns['smaller_side_coverage'] >= rules['minimum_coverage']
    strong_axis = rows['shared_count'] >= rules['strong_axis_shared_labels'] and row_good or columns['shared_count'] >= rules['strong_axis_shared_labels'] and col_good
    if not a['supported'] or not b['supported']:
        decision = 'needs_review'
    elif row_good and col_good or strong_axis:
        decision = 'matched'
    elif rows['shared_count'] == 0 and columns['shared_count'] == 0 and a['rows'] and b['rows'] and a['columns'] and b['columns']:
        decision = 'unmatched'
    else:
        decision = 'needs_review'
    mapping_status='aligned_labels' if row_good and col_good else ('partial_labels' if rows['shared_count'] or columns['shared_count'] else 'unresolved')
    return {'decision': decision, 'method': 'same_axis_labels_v2', 'transpose_checked': False,
        'item_correspondence':{'status':mapping_status,'rows':rows,'columns':columns,
            'cell_values_aligned':False,'unit_conversion_performed':False,
            'scope':'동일 축 라벨 대응만 수행; 셀 값 대응 아님'},
        'rows': rows, 'columns': columns, 'current_axes': a, 'prior_axes': b,
        'thresholds': {'smaller_side_coverage': rules['minimum_coverage'], 'strong_axis_shared_labels': rules['strong_axis_shared_labels']},
        'note': '머리글·행 라벨은 규칙 기반 추정. 값 셀 대응 또는 실제 병합은 수행하지 않음.'}
