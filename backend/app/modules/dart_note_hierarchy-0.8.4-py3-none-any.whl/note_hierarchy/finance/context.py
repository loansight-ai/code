"""Content metrics and table/context units; inference never changes block ownership."""
from lxml import html
from ..settings import get_config
import re

# chars/table_shape/measure remain compatibility exports for table_content.py.
from ..engine.metrics import chars,table_shape,measure,attach_content_metrics
from ..engine.table_context import neighbor_block_ids, breadcrumb

def qualifier(text):
    from .periods import unit_marker
    return bool(unit_marker(text) or re.fullmatch(get_config()['context']['qualifier_pattern'],text))
def note_text(text):return bool(re.match(get_config()['context']['footnote_pattern'],text))
def intro(text):return bool(re.search(get_config()['context']['intro_pattern'],text))



def enrich(data,root):
    rules=get_config()['context']
    blocks=data['blocks']; nodes=data['nodes']; byid={n['id']:n for n in nodes}; bmap={b['id']:b for b in blocks}
    units=[]; shape={};table_elements={}
    for i,b in enumerate(blocks):
        if b['type']!='table':continue
        el=root.xpath(b['source_xpath'])[0];shape[b['id']]=table_shape(el);table_elements[b['id']]=el
        owner=byid[b['owner_node_id']];flags=[]
        pre,post,j=neighbor_block_ids(blocks,i,owner['id'],stop_after=lambda q:
            qualifier(q['text_normalized']) or (intro(q['text_normalized']) and not note_text(q['text_normalized'])))
        if not pre:flags.append('직전 도입문 없음: 항목 제목을 문맥으로 사용')
        if post and j<len(blocks) and blocks[j]['type']=='table':flags.append('다음 표와 사이 설명의 귀속 검토')
        caption=[bid for bid in pre if not qualifier(bmap[bid]['text_normalized']) and not note_text(bmap[bid]['text_normalized']) and re.search(r'[가-힣A-Za-z]',bmap[bid]['text_normalized']) and len(bmap[bid]['text_normalized'])<=rules['caption_max_characters'] and not intro(bmap[bid]['text_normalized']) and not bmap[bid].get('heading_node_id') and not re.search(rules['caption_sentence_pattern'],bmap[bid]['text_normalized'])]
        lead=[bid for bid in pre if intro(bmap[bid]['text_normalized'])]
        # Never fabricate a table title: explicitly distinguish candidate captions from headings.
        title_id=caption[-1] if caption else (lead[-1] if lead else owner.get('source_block_id'))
        title_kind='caption_candidate' if caption else ('intro_sentence' if lead else 'item_heading_fallback')
        if title_kind!='caption_candidate':flags.append('독립 표 제목 미확정: 도입문/항목명으로 표시')
        crumbs=breadcrumb(owner,byid)
        unit={'id':'tbl_'+b['id'],'table_block_id':b['id'],'owner_node_id':owner['id'],'source_xpath':b['source_xpath'],
              'shape':shape[b['id']],'display_title':bmap[title_id]['text_normalized'] if title_id else '표',
              'title_source':title_kind,'title_block_id':title_id,'breadcrumb':crumbs,
              'before_block_ids':pre,'after_block_ids':post,'shared_before_block_ids':[],'shared_after_block_ids':[],
              'context_status':'heuristic_needs_review','review_flags':flags,'raw_table_html':html.tostring(el,encoding='unicode',with_tail=False),
              'html_file':'tables/tbl_'+b['id']+'.html','group_id':None}
        units.append(unit)
    # Adjacent period/unit variants are separate tables with a shared lead-in and closing note.
    groups=[]
    for unit in units:
        if groups:
            prev=groups[-1][-1];a=bmap[prev['table_block_id']]['order'];z=bmap[unit['table_block_id']]['order']
            between=blocks[a+1:z]
            join=unit['owner_node_id']==prev['owner_node_id'] and all(not b.get('heading_node_id') and b['type']!='table' and qualifier(b['text_normalized']) for b in between)
        else:join=False
        if join:groups[-1].append(unit)
        else:groups.append([unit])
    for group in groups:
        if len(group)<2:continue
        gid='grp_'+group[0]['id'];shared_pre=[bid for bid in group[0]['before_block_ids'] if not qualifier(bmap[bid]['text_normalized'])]
        for unit in group:
            unit['group_id']=gid;unit['shared_before_block_ids']=shared_pre
            unit['shared_after_block_ids']=group[-1]['after_block_ids']
            unit['review_flags'].append('연속 표 묶음의 도입문·후행 설명 공유: 의미 범위 검토')
    attach_content_metrics(data,shape)
    for unit in units:
        ids=set(unit['before_block_ids']+unit['after_block_ids']+unit['shared_before_block_ids']+unit['shared_after_block_ids'])
        unit['context_blocks']=[{'block_id':b['id'],'text':b['text'],'source_xpath':b['source_xpath'],
              'segment':b.get('segment'),'role_inferred':'unit_or_period' if qualifier(b['text_normalized']) else ('footnote' if note_text(b['text_normalized']) else ('intro' if intro(b['text_normalized']) else ('heading' if b.get('heading_node_id') else 'explanation_or_caption')))} for b in blocks if b['id'] in ids]
    data['table_units']=[{k:v for k,v in u.items() if k!='raw_table_html'} for u in units]
    data['content_metrics_definition']={'character_unit':'Unicode code points excluding whitespace','context_in_metrics':False,
        'layout_tables':'class=nb is layout, not counted as data tables; raw HTML remains preserved'}
    data['content_metrics_definition']['table_count']='class=nb 이외의 바깥 표를 한 단위로 계산. 중첩 table 요소 수는 html_table_elements에 별도 표시.'
    data['content_metrics_definition']['table_rows_cells']='해당 바깥 table에 직접 속하는 행·셀 수. 결합 셀은 1개로 계산.'
    return units,table_elements


# Compatibility export; rendering itself stays in rendering/tables.py.
from ..rendering.tables import render_unit
