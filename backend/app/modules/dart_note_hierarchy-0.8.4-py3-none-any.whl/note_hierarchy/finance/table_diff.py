"""Order-preserving structural diff prototype; never establishes semantic identity."""
from collections import Counter
from difflib import SequenceMatcher
from ..engine.common import norm
from ..settings import get_config
from .table_matching import analyze_table
from .header_features import feature_path


def extract_matrix(unit):
    axes, layout = analyze_table(unit)
    if not axes['supported']:
        raise ValueError(axes.get('reason','unsupported table'))
    origins = layout['source_cells']
    width = layout['width']
    grid = [[cell['display_text'] if cell else '' for cell in row] for row in layout['grid']]
    hc=axes['header_rows_inferred'];boundary=axes['value_start_column']
    headers=[]
    for ci in range(width):
        path=[]
        for ri in range(hc):
            t=grid[ri][ci]
            if t and (not path or norm(path[-1])!=norm(t)):path.append(t)
        headers.append({'column':ci,'path':path,'key':' / '.join(norm(t) for t in path)})
    section=[];rows=[]
    for ri in range(hc,len(grid)):
        own=origins[ri]
        if len(own)==1 and own[0]['colspan']>=width:
            section=[own[0]['display_text']];continue
        path=[]
        for t in grid[ri][:boundary]:
            if t and (not path or norm(path[-1])!=norm(t)):path.append(t)
        rows.append({'source_row':ri,'section':list(section),'path':path,
            'key':' / '.join(norm(t) for t in section+path),'values':grid[ri][boundary:],
            'raw_cells':grid[ri]})
    return {'headers':headers,'rows':rows,'value_start_column':boundary,
            'header_rows':hc,'header_evidence':axes['header_evidence']}


def lcs_diff(a,b):
    """Indices of exact matches/additions/deletions, retaining order and duplicates."""
    if len(a)*len(b)>get_config()['limits']['max_lcs_cells']:raise ValueError('LCS grid too large for prototype')
    dp=[[0]*(len(b)+1) for _ in range(len(a)+1)]
    for i in range(len(a)-1,-1,-1):
        for j in range(len(b)-1,-1,-1):
            dp[i][j]=1+dp[i+1][j+1] if a[i]==b[j] else max(dp[i+1][j],dp[i][j+1])
    i=j=0;ops=[];ca=Counter(a);cb=Counter(b)
    while i<len(a) or j<len(b):
        if i<len(a) and j<len(b) and a[i]==b[j]:
            ops.append({'op':'equal','current':i,'prior':j,'ambiguous_duplicate':ca[a[i]]>1 or cb[b[j]]>1});i+=1;j+=1
        elif i<len(a) and (j==len(b) or dp[i+1][j]>=dp[i][j+1]):
            ops.append({'op':'current_only','current':i,'prior':None});i+=1
        else:
            ops.append({'op':'prior_only','current':None,'prior':j});j+=1
    return ops


def diff_tables(current,prior,*,normalize_headers=False,compare_values=True):
    a,b=extract_matrix(current),extract_matrix(prior)
    for matrix in (a,b):
        for header in matrix['headers']:
            header['raw_key']=header['key']
            if normalize_headers:
                header['separated']=feature_path(header['path'])
                header['key']=header['separated']['key']
        for row in matrix['rows']:
            row['raw_key']=row['key']
            if normalize_headers:
                row['separated']=feature_path(row['section']+row['path'])
                row['key']=row['separated']['key']
    column_ops=lcs_diff([h['key'] for h in a['headers']],[h['key'] for h in b['headers']])
    row_ops=lcs_diff([r['key'] for r in a['rows']],[r['key'] for r in b['rows']])
    value_columns=[o for o in column_ops if o['op']=='equal' and not o.get('ambiguous_duplicate')
                   and o['current']>=a['value_start_column'] and o['prior']>=b['value_start_column']]
    changes=[]
    for o in row_ops if compare_values else []:
        if o['op']!='equal' or o.get('ambiguous_duplicate'):continue
        for co in value_columns:
            x=a['rows'][o['current']]['raw_cells'][co['current']]
            y=b['rows'][o['prior']]['raw_cells'][co['prior']]
            changes.append({'current_row':o['current'],'prior_row':o['prior'],
                'current_column':co['current'],'prior_column':co['prior'],
                'current_value':x,'prior_value':y,'changed':norm(x)!=norm(y)})
    # Textual rename suggestions only within each gap between exact LCS anchors.
    suggestions=[];gap=[]
    def flush():
        xs=[o['current'] for o in gap if o['op']=='current_only']
        ys=[o['prior'] for o in gap if o['op']=='prior_only']
        for i in xs:
            x=a['rows'][i]
            for j in ys:
                y=b['rows'][j]
                if not x['path'] or not y['path']:continue
                if [norm(t) for t in x['section']+x['path'][:-1]] != [norm(t) for t in y['section']+y['path'][:-1]]:continue
                score=SequenceMatcher(None,norm(x['path'][-1]),norm(y['path'][-1]),autojunk=False).ratio()
                if score>=get_config()['diff']['rename_suggestion_min_similarity']:suggestions.append({'current':i,'prior':j,'text_similarity':score,
                    'status':'review_only','accepted_as_identity':False,
                    'current_label':x['path'][-1],'prior_label':y['path'][-1]})
    for o in row_ops:
        if o['op']=='equal':flush();gap=[]
        else:gap.append(o)
    flush()
    summary={'current_data_rows':len(a['rows']),'prior_data_rows':len(b['rows']),
        'exact_row_matches':sum(o['op']=='equal' for o in row_ops),
        'current_only_rows':sum(o['op']=='current_only' for o in row_ops),
        'prior_only_rows':sum(o['op']=='prior_only' for o in row_ops),
        'exact_header_matches':sum(o['op']=='equal' for o in column_ops),
        'rename_suggestions':len(suggestions),'unambiguous_compared_value_cells':len(changes),
        'changed_value_cells':sum(c['changed'] for c in changes),
        'automatic_table_identity_decision':False,'transpose_checked':False,
        'header_metadata_separated':normalize_headers,'value_diff_performed':compare_values,
        'row_matches_after_separation':sum(o['op']=='equal' and a['rows'][o['current']]['raw_key']!=b['rows'][o['prior']]['raw_key'] for o in row_ops),
        'header_matches_after_separation':sum(o['op']=='equal' and a['headers'][o['current']]['raw_key']!=b['headers'][o['prior']]['raw_key'] for o in column_ops)}
    return {'method':'lcs_with_separated_header_metadata' if normalize_headers else 'exact_lcs_with_review_only_label_suggestions','summary':summary,
        'current':a,'prior':b,'column_diff':column_ops,'row_diff':row_ops,
        'label_change_suggestions':suggestions,'value_diff':changes}
