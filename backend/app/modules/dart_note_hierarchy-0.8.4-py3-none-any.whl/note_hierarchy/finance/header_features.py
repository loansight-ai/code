"""Separate header metadata without equating meaningful accounting qualifiers."""
import re

from ..settings import DEFAULT_CONFIG, get_config

PERIOD=re.compile(DEFAULT_CONFIG['headers']['period_pattern'])
UNITS=frozenset(DEFAULT_CONFIG['headers']['units'])


def split_header(text):
    rules=get_config()['headers']
    period_pattern=re.compile(rules['period_pattern'])
    raw=text
    t=re.sub(r'\s+','',text).replace('（','(').replace('）',')')
    annotations=[];qualifiers=[];units=[];company=[];warnings=[];periods=[]
    if t.count('(')!=t.count(')') or re.search(r'\([^)]*\(',t):
        warnings.append('복합·불균형 괄호: 원문 키 유지')
        return {'raw':raw,'base':t,'annotations':[],'qualifiers':[],'units':[],
                'periods':[],'company_markers':[],'matching_key':t,'warnings':warnings}
    def parenthesis(m):
        content=m.group(1)
        if period_pattern.fullmatch(content):return content
        if re.fullmatch(rules['annotation_pattern'],content):
            annotations.append(m.group(0));return ''
        if content==rules['company_word'] and m.start()==0:
            company.append(m.group(0));return ''
        if content==rules['company_word'] and m.end()==len(t) and not re.search(rules['share_quantity_pattern'],t[:m.start()]):
            company.append(m.group(0));return ''
        if content in rules['units']:
            units.append(content);return ''
        qualifiers.append(content);return ''
    base=re.sub(r'\(([^()]*)\)',parenthesis,t)
    if rules['company_symbol'] in base:company.append(rules['company_symbol']);base=base.replace(rules['company_symbol'],'')
    # '당기손익' is an accounting concept, not just the period marker '당기'.
    protected=[]
    def protect(m):
        protected.append(m.group(0));return f'§{len(protected)-1}§'
    if rules['protected_terms']:base=re.sub('|'.join(re.escape(t) for t in rules['protected_terms']),protect,base)
    def period(m):
        token=m.group(0)
        # Do not remove lexical '전기' (electricity) or substrings inside a company
        # name. Unknown compound words are retained rather than forced to match.
        tail=base[m.end():]
        finance_tail=re.match('|'.join(re.escape(t) for t in rules['finance_tail_terms']),tail) if rules['finance_tail_terms'] else None
        if company or (m.start()!=0 and m.end()!=len(base)):
            return token
        if tail and token in rules['bare_duration_markers'] and not finance_tail:
            return token
        basis='end' if token.endswith(get_config()['periods']['end_suffix']) else ('begin' if token.endswith(get_config()['periods']['begin_suffix']) else 'duration')
        horizon='quarter' if get_config()['periods']['quarter_term'] in token else ('half' if get_config()['periods']['half_term'] in token else 'annual')
        periods.append({'text':token,'role':'current' if token.startswith(get_config()['periods']['current_prefix']) else 'prior','basis':basis,'horizon':horizon})
        return ''
    base=period_pattern.sub(period,base)
    for i,value in enumerate(protected):base=base.replace(f'§{i}§',value)
    key=base
    if qualifiers:key+=''.join('〈'+q+'〉' for q in qualifiers)
    if periods:
        # Normalize current/prior, while retaining the time basis and horizon.
        key+=''.join('〔PERIOD:'+p['basis']+':'+p['horizon']+'〕' for p in periods)
    return {'raw':raw,'base':base,'annotations':annotations,'qualifiers':qualifiers,
            'units':units,'periods':periods,'company_markers':company,'matching_key':key,'warnings':warnings}


def feature_path(path):
    features=[split_header(t) for t in path]
    return {'features':features,'key':' / '.join(f['matching_key'] for f in features if f['matching_key'])}
