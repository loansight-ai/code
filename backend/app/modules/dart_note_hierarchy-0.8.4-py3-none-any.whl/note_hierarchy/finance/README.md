# 표·기간 연결

DART 프로필은 표와 주변 문맥·크기를 추출한다. `DocumentProcessor("dart", link_periods=True)`이면 당기·전기 표 연결도 수행한다. 금액 합산, 전치 비교, 다른 연도 보고서 간 연결은 하지 않는다.

| 모듈 | 책임 |
|---|---|
| `context.py` | 표 원문, 소속 노드, 주변 제목·도입문·단위·각주와 크기 |
| `period_labels.py`, `periods.py` | 기간 표지와 주제 제목 연결 판정 |
| `table_matching.py` | 다단 머리글·같은 축 라벨·기간 역할 비교 |
| `header_features.py` | 헤더의 기본명·주석·기간·단위·의미 한정어 분리 |
| `period_runs.py` | 연속 당기·전기 묶음의 유일한 대응 후보 |
| `table_diff.py` | 순서 보존 라벨 LCS 대응 |

## 후보와 판정

같은 직속 계층의 데이터 표가 원문 순서상 연속하고 `당기 → 전기`로 대응하면 후보로 잡는다. `당기말 → 전기말`도 포함한다. `당기 → 전기 → 전기`에서는 앞의 두 표만 후보가 된다. 설명·각주·새 도입문은 검토 근거로 남기며 고정 문단 수 거리 제한은 사용하지 않는다.

`당기·당기·전기·전기`처럼 양쪽이 2개 이상 연속하면 묶음을 먼저 예약한다. 모든 교차 조합을 비교하고 양쪽에서 각각 유일하게 대응하는 표 쌍을 선택한다. 중간 경계의 두 표를 인접 규칙으로 다시 선택하지 않는다. 양쪽 개수나 순서가 같다는 이유만으로 연결하지 않는다.

병합 셀을 비교용 그리드로 펼치고 행은 행끼리, 열은 열끼리 비교한다. 행·열 개수나 병합 모양 차이만으로 제외하지 않는다. 전치는 하지 않는다. 단위·독립 제목·기간 역할 충돌도 검토한다. 임계값은 [설정 문서](../config/README.md)의 `matching`, `period_runs`에 있다.

## 결과를 구분해서 읽기

- `period_table_candidates`: 후보 전체. `match_status`는 `matched`, `needs_review`, `unmatched`다.
- `title_linking`: 같은 공시 주제를 나타낸다는 제목 연결 판정.
- `item_correspondence`: 같은 축 항목 라벨의 대응 근거. 셀·금액의 일대일 대응은 아니다.
- `period_title_links`: 연결된 제목 그룹. 표 HTML을 합친 결과는 아니다.
- `period_table_runs`: 묶음의 교차 비교·선택 쌍·보류 표. 선택과 최종 연결은 구분한다.

전체 표의 `table_period`와 셀 안의 기초·기말·기간 축을 분리한다. 전기 표 안의 전기초·전기말은 그 자체로 충돌이 아니다.

원문 헤더를 보존하면서 `(주1)` 같은 각주와 기간 표현을 비교용으로 분리한다. `(유동)`, `(비유동)`, `(손실)` 같은 의미 한정어와 `당기손익`은 무조건 삭제하지 않는다. 단위·중복 라벨·괄호 불확실성은 보류 근거가 될 수 있다.

## 별도 diff 분석

```python
from note_hierarchy.finance.table_diff import diff_tables

comparison = diff_tables(
    current_unit,
    prior_unit,
    normalize_headers=True,
    compare_values=False,
)
```

입력은 `result.table_units`의 표 단위 객체다. 순서 보존 라벨 정렬이며 이 호출이 기존 자동 연결 결과를 변경하지는 않는다. 항목 변동과 의미적 동일성은 별도로 평가해야 한다.

표 문맥도 휴리스틱이다. `raw_table_html`과 원문 위치를 함께 보존하므로 검토 화면에서 확인할 수 있다.
