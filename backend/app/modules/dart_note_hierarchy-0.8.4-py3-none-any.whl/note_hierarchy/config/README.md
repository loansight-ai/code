# 구조화 설정

`default.json`이 임계값·어휘·정규식의 기본 설정 파일이다. 현재 계층 전략은 `top_down`이며 과거 방식은 `sequential`로 선택한다. `example.override.json`은 부분 설정 예시이며 생략한 키는 현재 기본값을 사용한다.

사용자 파일을 따로 만들고 필요한 항목만 덮어쓰는 방식을 권장한다. 기본 설정 파일은 패키지를 처음 import할 때 읽는다. 실행 중 JSON을 수정했다면 새 처리기를 만들면서 해당 파일을 `config=`로 지정하면 다시 읽는다. `config`를 생략한 기존 호출은 초기 로드된 기본값을 사용한다.

## Python API

```python
from note_hierarchy import DocumentProcessor

processor = DocumentProcessor(
    "dart",
    link_periods=True,
    config="my_rules.json",
)
result = processor.process_file("notes.html")
result.write("result")
```

딕셔너리도 전달할 수 있다.

```python
processor = DocumentProcessor(
    "dart",
    link_periods=True,
    config={
        "matching": {"minimum_coverage": 0.9},
        "context": {"caption_max_characters": 120},
    },
)
```

위 예시는 개별 표 라벨 대응 기준과 표 제목 후보 길이를 바꾼다. 연속 기간 묶음의 기준은 별도 `period_runs.minimum_coverage`이므로 두 기준을 함께 바꾸려면 각각 지정한다.

## CLI

```powershell
python -m note_hierarchy notes.html --profile dart --link-periods --config my_rules.json --output result
```

## 설정 영역

| 영역 | 내용 | 주요 기본값·키 |
|---|---|---|
| `profiles.generic`, `profiles.dart` | 문서 프로필, 클래스·태그·문장 종결·제외 정규식 | `max_marker_value`, `max_unnumbered_heading_length`, `sentence_end_pattern`, `candidate_exclusions` |
| `hierarchy` | 계층 전략·분할 번호·제목 판단 | `strategy=top_down`, `allow_integer_enclosure_variants=true`, `support_split_sibling_numbers=true`, `split_sibling_min_members=2`, `top_title_max_exclusive=95`, `numbered_item_min_exclusive=110`, `max_numeric_path_parts=6` |
| `markers` | 번호 문법의 정규식과 한글 번호 문자 | `patterns`, `hangul_alphabet` |
| `context` | 표 제목·도입문·각주·기간 문맥 | `caption_max_characters=100`, `intro_pattern`, `footnote_pattern`, `qualifier_pattern`, `caption_sentence_pattern` |
| `periods` | 단독 기간·단위·주제 판단·원본 서명 정규화 | `label_pattern`, `unit_marker_pattern`, `generic_columns`, `informative_min_characters=4` |
| `headers` | 헤더 기간·단위·회사 표기·보호 표현·분리 허용 어휘 | `units`, `protected_terms`, `finance_tail_terms`, `annotation_pattern`, `bare_duration_markers` |
| `matching` | 기존 단일 후보의 같은 축 라벨 비교 | `ignored_labels`, `row_header_extra_labels`, `minimum_coverage=0.8`, `strong_axis_shared_labels=2`, `max_header_rows=32` |
| `period_runs` | 연속 당기 묶음→전기 묶음 비교 | `minimum_run_tables=2`, `minimum_coverage=0.8`, `strong_columns_min_distinctive=3`, `generic_labels` |
| `limits` | 계산량 제한 | `max_rows=5000`, `max_columns=512`, `max_rowspan=5000`, `max_expanded_cells=200000`, `max_lcs_cells=1000000` |
| `diff` | 검토용 이름 변경 제안 기준 | `rename_suggestion_min_similarity=0.6`; 자동 동일성 판정은 아님 |

`exclusive`가 붙은 길이는 기존과 같이 엄격한 `<` 또는 `>` 비교다. 길이 판단에 쓰는 문자열과 집계용 공백 제외 글자수는 처리 목적이 다르므로 같은 측정치로 간주하지 않는다. `max_numeric_path_parts`는 명시된 숫자 경로의 길이이며 전체 트리 최대 depth가 아니다.

## 병합과 검증

- 딕셔너리는 항목별로 기본값과 병합한다. 지정하지 않은 값은 유지한다.
- **배열은 추가가 아니라 전체 교체**다. 어휘를 추가하려면 기존 목록을 포함해야 한다.
- 정규식은 JSON 문자열 규칙에 따라 `\`를 `\\`로 적는다. 어휘 목록의 항목은 정규식이 아니라 일반 문자열로 취급한다.
- 알 수 없는 설정 이름, 잘못된 자료형·정규식, 음수/0 제한, 0~1 범위를 벗어난 비율은 거부한다. 기간 묶음 최소 표 수는 2 이상이다.
- `markers.patterns`는 기존 파서가 해석하는 번호 종류를 대상으로 하며, 정규식에 `mark`, `title` 이름의 그룹이 있어야 한다. 새로운 번호 종류의 의미 해석까지 설정만으로 생성하지는 않는다.
- `HtmlProfile` 객체를 직접 전달하면 그 객체의 프로필 필드를 우선한다. 나머지 `hierarchy`, `headers`, `matching` 등의 설정은 그대로 적용된다.

## 저수준 함수와 처리기 간 격리

공개 처리기는 호출 동안 자신의 설정을 활성화하고 종료·예외 발생 시 복원한다. 설정 값은 읽기 전용이며 처리기끼리 전역 변수를 덮어쓰지 않는다. 서로 다른 설정으로 스레드에서 실행할 수 있다.

`split_header()`, `compare_labels()`, `link_period_tables()` 같은 저수준 함수를 직접 호출할 때는 범위를 지정한다.

```python
from note_hierarchy import config_scope
from note_hierarchy.finance.header_features import split_header

with config_scope("my_rules.json"):
    features = split_header("당기공사수익(주1)")
```

기존 모듈의 `LABEL`, `IGNORED`, `UNITS` 같은 상수는 호환용 기본값이다. 사용자 설정은 활성 설정을 읽는 함수에 적용되며, 이 상수들을 직접 수정해서 설정을 바꾸지 않는다.

## 결과 재현

`processor.config.sha256`으로 해석된 전체 설정의 해시를 확인할 수 있다. 기본값과 다른 설정으로 처리하면 `structure.json`의 `configuration`에 전체 유효 설정과 해시를 저장한다. 기본 설정에서는 기존 결과 스키마를 유지한다.

프로필 클래스 이름, 블록·노드 ID 형식, 원문 보존과 소속 경계 같은 알고리즘의 구조 자체는 설정 파일로 바꾸지 않는다. 배치 실행 파일의 입력 경로·기준 문서 수·통계 구간과 HTML 화면의 스타일도 이 구조화 설정의 범위에 포함하지 않았다.

다른 프로젝트로 복사할 때는 **`settings.py`와 `config/`를 반드시 포함**한다. 실행에 필요한 정확한 범위와 최소 배포 ZIP은 [사용방법](../사용방법.md)을 참고한다. 새 외부 의존성은 없다.


## 확장 한글 번호와 기존 순차 전략

아래 depth별 현재 상태 설명은 `hierarchy.strategy="sequential"`에 해당한다. 기본 탑다운 방식은 [엔진 구성](../engine/README.md)처럼 전체 후보와 부모 범위를 먼저 분석한다. 한글 번호 문자 설정은 두 방식이 공통으로 사용한다.

기본 `markers.hangul_alphabet`은 `가나다라마바사아자차카타파하거너더러머버서어저처커터퍼허`다. 번호 정규식의 `[{hangul}]`은 이 문자 목록으로 치환된다. 목록을 바꾸면 인식 문자와 순서가 함께 바뀐다. `가~하` 이후 `거`는 15번, `허`는 28번이며 `(거)`와 `거.`는 다른 형식으로 구분한다.

명시적인 숫자 경로는 현재 depth별로 확인한 같은 형식·같은 부모 경로의 형제를 먼저 찾는다. 이어지는 번호이면 같은 depth에 연결하고 하위 상태를 종료한다. 번호 건너뜀은 별도 플래그를 남기며, 부모 경로가 다르면 같은 형제로 연결하지 않는다. 처음 나타나는 괄호 없는 `2-1`은 일치하는 상위 `2.`를 우선하고, `(1) → (1-1)`과 상위 접두사가 다른 `1) → 1-1)` 같은 기존 지역 경로는 유지한다. 모호한 같은 형식 재시작을 무조건 자식으로 연결하는 규칙은 추가하지 않았다.
