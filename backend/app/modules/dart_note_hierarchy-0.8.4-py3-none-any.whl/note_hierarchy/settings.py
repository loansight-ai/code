"""Validated immutable JSON rules, scoped to a processor invocation."""
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
import hashlib, json, re

DEFAULT_CONFIG_PATH = Path(__file__).with_name('config')/'default.json'


def _freeze(value):
    if isinstance(value, dict): return MappingProxyType({k:_freeze(v) for k,v in value.items()})
    if isinstance(value, list): return tuple(_freeze(v) for v in value)
    return value


def _thaw(value):
    if isinstance(value, (dict, MappingProxyType)): return {k:_thaw(v) for k,v in value.items()}
    if isinstance(value, tuple): return [_thaw(v) for v in value]
    return value


def _merge(base, patch, path=''):
    if not isinstance(patch, dict): raise ValueError(f'{path or "config"}: object required')
    result=dict(base)
    for key, value in patch.items():
        name=f'{path}.{key}' if path else key
        if key not in base: raise ValueError(f'Unknown setting: {name}')
        default=base[key]
        if isinstance(default, dict): result[key]=_merge(default,value,name)
        else:
            valid=(value is None or isinstance(value,str)) if default is None else (
                type(value) is type(default) or isinstance(default,float) and type(value) in (int,float))
            if not valid: raise ValueError(f'{name}: invalid type')
            if isinstance(default,list):
                if key=='patterns':
                    if any(not isinstance(v,list) or len(v)!=2 or not all(isinstance(x,str) for x in v) for v in value):
                        raise ValueError(f'{name}: expected [marker_type, regex] pairs')
                elif any(not isinstance(v,str) for v in value): raise ValueError(f'{name}: string list required')
            result[key]=value
    return result


def _validate(data):
    def visit(value, path=''):
        if isinstance(value, dict):
            for key,item in value.items():
                name=f'{path}.{key}' if path else key
                if key.endswith('_pattern') and item is not None:
                    try: re.compile(item)
                    except re.error as exc: raise ValueError(f'{name}: {exc}') from exc
                if key=='candidate_exclusions':
                    for pattern in item: re.compile(pattern)
                visit(item,name)
        elif type(value) in (int,float):
            if value<=0: raise ValueError(f'{path}: must be positive')
            if ('coverage' in path or 'similarity' in path) and not 0<value<=1:
                raise ValueError(f'{path}: expected 0 < value <= 1')
    visit(data)
    if data['hierarchy']['strategy'] not in ('top_down','sequential'):
        raise ValueError('hierarchy.strategy: expected top_down or sequential')
    if data['hierarchy']['split_sibling_min_members']<2:
        raise ValueError('hierarchy.split_sibling_min_members: must be >= 2')
    if data['period_runs']['minimum_run_tables']<2: raise ValueError('period_runs.minimum_run_tables: must be >= 2')
    for kind,pattern in data['markers']['patterns']:
        regex=re.compile(pattern.replace('{hangul}',re.escape(data['markers']['hangul_alphabet'])))
        if not {'mark','title'}<=regex.groupindex.keys(): raise ValueError('markers.patterns: named mark/title groups required')
    if re.compile(data['periods']['unit_extract_pattern']).groups<1:
        raise ValueError('periods.unit_extract_pattern: capture group required')
    for key in ('company_word','company_symbol'):
        if not data['headers'][key]: raise ValueError(f'headers.{key}: cannot be empty')
    for key in ('current_prefix','end_suffix','begin_suffix','quarter_term','half_term'):
        if not data['periods'][key]: raise ValueError(f'periods.{key}: cannot be empty')
    for key in ('finance_tail_terms','protected_terms'):
        if any(not term for term in data['headers'][key]): raise ValueError(f'headers.{key}: empty terms forbidden')


@dataclass(frozen=True)
class RulesConfig:
    _data: object
    sha256: str

    def __init__(self,data):
        _validate(data)
        object.__setattr__(self,'_data',_freeze(data))
        object.__setattr__(self,'sha256',hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode()).hexdigest())

    def __getitem__(self,key): return self._data[key]
    def to_dict(self): return _thaw(self._data)


_DEFAULT_DATA=json.loads(DEFAULT_CONFIG_PATH.read_text(encoding='utf-8'))
DEFAULT_CONFIG=RulesConfig(_DEFAULT_DATA)
_ACTIVE=ContextVar('note_hierarchy_rules',default=DEFAULT_CONFIG)


def load_config(source=None):
    """Accept a JSON path, partial dictionary, or already loaded configuration."""
    if source is None: return DEFAULT_CONFIG
    if isinstance(source,RulesConfig): return source
    patch=json.loads(Path(source).read_text(encoding='utf-8-sig')) if isinstance(source,(str,Path)) else source
    return RulesConfig(_merge(_DEFAULT_DATA,patch))


def get_config(): return _ACTIVE.get()


@contextmanager
def config_scope(config):
    token=_ACTIVE.set(load_config(config))
    try: yield _ACTIVE.get()
    finally: _ACTIVE.reset(token)


def processor_rules(method):
    @wraps(method)
    def wrapped(self,*args,**kwargs):
        with config_scope(self.config): return method(self,*args,**kwargs)
    return wrapped
