# DART 재무제표 주석 구조화

현재 버전: **0.8.4**. DART 사업보고서의 연결·별도 **재무제표 주석 HTML**을 로컬에서 처리한다. 번호 계층, 본문 블록, 표·주변 설명, 내용 크기와 당기·전기 표 연결을 반환한다. 수집기와 API 키는 필요하지 않다.

## 바로 실행

Python 3.10 이상이 필요하다. 저장소 루트에서 설치하거나 배포받은 wheel을 설치한다.

```powershell
python -m pip install .
# 또는 배포 파일 설치
python -m pip install ./dart_note_hierarchy-0.8.4-py3-none-any.whl
python -m note_hierarchy input/notes.html --profile dart --link-periods --period 2025.12 --kind 별도 --output outputs/notes_review
```

`outputs/notes_review/review.html`에서 트리와 본문을 함께 확인한다. API와 CLI의 기본 프로필은 `generic`이므로 DART 입력에는 `dart`를 명시한다.

```python
from note_hierarchy import DocumentProcessor

processor = DocumentProcessor("dart", link_periods=True)
result = processor.process_file(
    "input/notes.html",
    document_id="company_2025_separate",
    metadata={"title": "기업명", "period": "2025.12", "kind": "별도"},
)
result.write("outputs/company_2025_separate")
```

## 다른 프로젝트에서 사용

설치를 권장한다. 설치 후에는 어느 작업 폴더에서든 `from note_hierarchy import DocumentProcessor`, `note-hierarchy` 또는 `python -m note_hierarchy`를 사용할 수 있다. 배포 이름은 `dart-note-hierarchy`, Python import 이름은 `note_hierarchy`이다.

소스 복사 방식도 지원한다. 실행용 ZIP을 프로젝트 루트에 풀면 된다. 소스를 직접 옮길 때는 `__init__.py`, `__main__.py`, `api.py`, `settings.py`, `requirements.txt`와 `engine/`, `adapters/`, `finance/`, `rendering/`, **`config/`**를 포함한다. 폴더 구조를 유지한다.

전체 소스에서 실행용 ZIP을 만드는 명령:

```powershell
python -m note_hierarchy.workflows.export_runtime --output outputs/note_hierarchy_runtime_0.8.4.zip
```

ZIP에는 런타임·설정·사용 문서·예제만 들어간다. 수집 원문, 기업 목록, API 키, 테스트, 데이터셋별 실행 스크립트와 기존 호환 스크립트는 포함하지 않는다. wheel과 소스 배포본(sdist)을 지원한다. PyPI에는 게시하지 않았다. 설치 패키지에는 과거 호환 스크립트와 평가용 workflows도 포함하지 않는다.

## 문서

- [사용방법](사용방법.md): 복사 범위, 설치, Python API, CLI, 출력 스키마, 말단·RAG 해석
- [엔진 구성](engine/README.md): 후보 추출, 탑다운 분할, 부분 관계 보존
- [설정](config/README.md): JSON 부분 덮어쓰기와 기본 규칙
- [표·기간 연결](finance/README.md): 표 문맥, 당기·전기 후보와 판정의 의미
- [변경 기록](CHANGELOG.md)

## 코드 구성

```text
note_hierarchy/
  api.py / __init__.py / __main__.py   공개 API와 단일 HTML CLI
  settings.py / config/               설정 로드·검증·호출별 격리
  engine/
    hierarchy.py                     전략 선택과 기존 import 호환
    candidates.py / markers.py       번호 후보와 원문 표기
    top_down.py / split_numbering.py  범위별 목록·부모·분할 번호 판정
    partial_relations.py              상위 소속·형제 순서 보존
    heading_candidates.py             번호 없는 제목 제안
    sequential.py / numbering_state.py  기존 순차 방식
    blocks.py / metrics.py / tables.py / validation.py
  adapters/                           DART 등 문서 규칙
  finance/                            표 문맥·기간·라벨 대응
  rendering/                          트리·본문·표 검토 HTML
  examples/                           가상 DART 예제와 일반 HTML 예제
  workflows/                          데이터셋 평가·통계·배포 도구
```

패키지 루트의 `structure_note_hierarchy.py`, `table_content.py`, `period_table_links.py`는 기존 import 호환층이다. 그 밖의 과거 실행·대시보드 파일도 기존 경로 호환을 위해 유지하지만 공개 API의 의존성은 아니다. 새 프로젝트에는 wheel 설치를 권장한다.

## 현재 판정과 한계

기본은 전체 후보 수집 후 상위 범위부터 나누는 `top_down`이다. 번호 누락·중복·괄호 전환을 국소적으로 처리하고, 근거가 있는 `33. → 34-1. → 34-2. → 35.`는 같은 레벨로 해석한다. 원래 번호와 숫자 경로를 보존하며 가상 부모를 만들지 않는다.

직접 부모가 미확정이어도 상위 주석 소속과 같은 목록 관계는 별도로 유지한다. 번호 없는 제목은 후보만 제시한다. 미확정이 적거나 구조 검증을 통과했다고 의미 정확도가 보장되지는 않는다.

PDF·XBRL·일반 XML, JavaScript 렌더링, 화면 좌표 분석은 지원하지 않는다. 검증 범위는 주로 사업보고서 주석이며 일반 HTML 프로필의 다른 문서 적용에는 별도 검증이 필요하다.

전체 소스의 회귀 테스트:

```powershell
python -m unittest discover -s note_hierarchy -p 'test_*.py' -q
```
